# B2B Design Atlas · V0.3 — Editorial White Edition

Independent design-reference prototype for global B2B website designers. The front-end is a custom editorial UI, not a generative site builder.

## Features

- White-first, typography-led home and navigation. No heavy gradients, fake metrics, rotating cards, or decorative AI illustrations.
- 12 original-source-URL-indexed real B2B companies and 25 manually authored page/section observations.
- Filters for company sector, module intent and a search query.
- Original structural diagrams are **not source screenshots**; click-through to official pages for the real visual designs.
- Original fictional concept studies are retained, but isolated under their own tab.
- Source-level detail views, related page notes, local bookmarks, design board, Markdown export.
- Existing curator endpoints retained with administrative token + screenshot authorization workflow.

## Run locally

```bash
pip install -r requirements.txt
python run.py
```

Visit http://localhost:8000. Use `PORT=8031 python run.py` to override the port.

## APIs

- `GET /api/source-library` — source-based public metadata index (12 companies, 25 notes)
- `GET /api/health` — version / health
- Original concept endpoints `/api/websites`, `/api/sections`, `/api/patterns` remain available.
- Protected editorial intake is separate, under `/api/admin/intake`.

## Provenance and limitations

- Sources are verified via public official pages on 2026-11-23. Descriptions analyze *information architecture* from those pages; they are not pixel-level critiques of a live screenshot.
- No third-party screenshot or source code is included in the website gallery. Original editorial diagrams are labeled as such.
- Live source URLs and page designs may change; continuous monitoring is not enabled.
- Source data is checked-in JSON (`app/source_index.json`) plus CSVs in `docs/`.
- Browser-based full visual regression could not be completed in this environment; responsive CSS plus API/JS validation were completed.
- Collections and Design Board use localStorage; no multi-user persistence. SQLite on free Render filesystem is ephemeral.
- Demo is not production hardened. Admin writes remain unavailable without `ATLAS_ADMIN_TOKEN`.

## Tests

```bash
python -m pytest -q
node --check static/assets/atlas-v03.js
```

## Deployment

Docker deploy through GitHub / Render, single web service. No cloud Postgres is attached; do not treat SQLite demo as production persistence.
