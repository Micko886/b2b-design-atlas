"""B2B Design Atlas v0.2: gallery + public catalog API + simple token-protected curator API.
No third-party site scraping or unauthorized screenshot downloads are performed.
"""
from __future__ import annotations

import os
import re
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Literal
from urllib.parse import urlparse

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from app.seed import PATTERNS, SECTIONS, WEBSITES

BASE = Path(__file__).resolve().parents[1]
STATIC = BASE / "static"
DB_FILE = Path(os.getenv("ATLAS_DB_PATH", str(BASE / "data" / "atlas.sqlite3")))
DB_FILE.parent.mkdir(parents=True, exist_ok=True)
app = FastAPI(title="B2B Design Atlas API", version="0.2.0")


@contextmanager
def db():
    connection = sqlite3.connect(DB_FILE)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
        connection.commit()
    finally:
        connection.close()


def init_db():
    with db() as con:
        con.executescript("""
            CREATE TABLE IF NOT EXISTS websites (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slug TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                industry TEXT NOT NULL,
                business_model TEXT NOT NULL DEFAULT '',
                style TEXT NOT NULL DEFAULT '',
                palette TEXT NOT NULL DEFAULT 'sand',
                tagline TEXT NOT NULL DEFAULT '',
                hero_title TEXT NOT NULL DEFAULT '',
                hero_kicker TEXT NOT NULL DEFAULT '',
                description TEXT NOT NULL DEFAULT '',
                design_note TEXT NOT NULL DEFAULT '',
                visual TEXT NOT NULL DEFAULT 'blocks',
                featured INTEGER NOT NULL DEFAULT 0,
                reference_type TEXT NOT NULL DEFAULT 'Original Study',
                source_url TEXT,
                image_url TEXT,
                published INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS sections (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slug TEXT NOT NULL UNIQUE,
                website_slug TEXT NOT NULL REFERENCES websites(slug),
                type TEXT NOT NULL,
                title TEXT NOT NULL,
                layout TEXT NOT NULL,
                summary TEXT NOT NULL DEFAULT '',
                principle TEXT NOT NULL DEFAULT '',
                pitfall TEXT NOT NULL DEFAULT '',
                content_fit TEXT NOT NULL DEFAULT '',
                visual TEXT NOT NULL DEFAULT 'blocks',
                palette TEXT NOT NULL DEFAULT 'sand',
                preview_caption TEXT NOT NULL DEFAULT '',
                badge TEXT NOT NULL DEFAULT 'Original Study',
                featured INTEGER NOT NULL DEFAULT 0,
                source_url TEXT,
                image_url TEXT,
                published INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slug TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                family TEXT NOT NULL,
                description TEXT NOT NULL,
                guidance TEXT NOT NULL,
                avoid TEXT NOT NULL,
                structure TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_sites_industry ON websites(industry);
            CREATE INDEX IF NOT EXISTS idx_sections_kind ON sections(type);
            CREATE INDEX IF NOT EXISTS idx_sections_layout ON sections(layout);
        """)
        if con.execute("SELECT COUNT(*) FROM websites").fetchone()[0] == 0:
            for item in WEBSITES:
                item = dict(item, reference_type="Original Study")
                cols = ', '.join(item)
                con.execute(f"INSERT INTO websites ({cols}) VALUES ({','.join('?' for _ in item)})", tuple(item.values()))
        if con.execute("SELECT COUNT(*) FROM sections").fetchone()[0] == 0:
            for item in SECTIONS:
                cols = ', '.join(item)
                con.execute(f"INSERT INTO sections ({cols}) VALUES ({','.join('?' for _ in item)})", tuple(item.values()))
        if con.execute("SELECT COUNT(*) FROM patterns").fetchone()[0] == 0:
            for item in PATTERNS:
                cols = ', '.join(item)
                con.execute(f"INSERT INTO patterns ({cols}) VALUES ({','.join('?' for _ in item)})", tuple(item.values()))


init_db()
app.mount("/assets", StaticFiles(directory=STATIC / "assets"), name="assets")


def rows(sql, params=()):
    with db() as con:
        return [dict(row) for row in con.execute(sql, params).fetchall()]


def single(sql, params=()):
    with db() as con:
        row = con.execute(sql, params).fetchone()
        return dict(row) if row is not None else None


def facets(source, field):
    return [r["value"] for r in rows(f"SELECT DISTINCT {field} AS value FROM {source} WHERE published=1 ORDER BY {field}")]


@app.get("/api/health")
def health():
    return {"ok": True, "version":"0.2.0", "mode": "curated starter with editorial workflow"}


@app.get("/api/stats")
def stats():
    return {
        "websites":single("SELECT COUNT(*) as count FROM websites WHERE published=1")["count"],
        "sections":single("SELECT COUNT(*) as count FROM sections s JOIN websites w ON s.website_slug=w.slug WHERE s.published=1 AND w.published=1")["count"],
        "patterns":single("SELECT COUNT(*) as count FROM patterns")["count"],
        "note":"Starter entries are fictional original design studies. Additional real references are editorially reviewed."
    }


@app.get("/api/facets")
def get_facets():
    return {
        "industries":facets("websites","industry"),
        "styles":facets("websites","style"),
        "business_models":facets("websites","business_model"),
        "types":facets("sections","type"),
        "layouts":facets("sections","layout")
    }


@app.get("/api/websites")
def get_websites(q:str="", industry:str="", style:str="", business_model:str="", sort:Literal["curated","name","newest"]="curated", limit:int=Query(100,ge=1,le=200)):
    sql="SELECT * FROM websites WHERE published=1"
    params=[]
    if q.strip():
        sql+=" AND (name LIKE ? OR industry LIKE ? OR description LIKE ? OR tagline LIKE ? OR business_model LIKE ?)"
        params += [f"%{q.strip()}%"]*5
    for key,val in [("industry",industry),("style",style),("business_model",business_model)]:
        if val: sql+=f" AND {key}=?";params.append(val)
    sql += {"curated":" ORDER BY featured DESC,id ASC", "name":" ORDER BY name COLLATE NOCASE", "newest":" ORDER BY id DESC"}[sort]
    sql += " LIMIT ?";params.append(limit)
    return {"items":rows(sql,params)}


@app.get("/api/websites/{slug}")
def get_website(slug:str):
    w=single("SELECT * FROM websites WHERE slug=? AND published=1",(slug,))
    if not w: raise HTTPException(404,"Website not found")
    w["sections"]=rows("SELECT * FROM sections WHERE website_slug=? AND published=1 ORDER BY id",(slug,))
    return w


@app.get("/api/sections")
def get_sections(q:str="", industry:str="", type:str="", layout:str="", style:str="", sort:Literal["curated","name","newest"]="curated", limit:int=Query(200,ge=1,le=500)):
    sql="""SELECT s.*,w.name AS website_name,w.industry,w.style,w.business_model
             FROM sections s JOIN websites w ON s.website_slug=w.slug
             WHERE s.published=1 AND w.published=1"""
    params=[]
    if q.strip():
        sql+=" AND (s.title LIKE ? OR s.type LIKE ? OR s.layout LIKE ? OR s.summary LIKE ? OR w.name LIKE ? OR w.industry LIKE ?)"
        params += [f"%{q.strip()}%"]*6
    for key,val in [("w.industry",industry),("s.type",type),("s.layout",layout),("w.style",style)]:
        if val: sql+=f" AND {key}=?";params.append(val)
    sql += {"curated":" ORDER BY s.featured DESC,s.id ASC", "name":" ORDER BY s.title COLLATE NOCASE", "newest":" ORDER BY s.id DESC"}[sort]
    sql += " LIMIT ?";params.append(limit)
    return {"items":rows(sql,params)}


@app.get("/api/sections/{slug}")
def get_section(slug:str):
    s=single("""SELECT s.*,w.name AS website_name,w.industry,w.style,w.business_model,w.description AS website_description
                 FROM sections s JOIN websites w ON s.website_slug=w.slug WHERE s.slug=? AND s.published=1 AND w.published=1""",(slug,))
    if not s: raise HTTPException(404,"Section not found")
    return s


@app.get("/api/patterns")
def get_patterns(q:str="", family:str=""):
    sql="SELECT p.*,(SELECT COUNT(*) FROM sections s JOIN websites w ON s.website_slug=w.slug WHERE s.layout=p.name AND s.published=1 AND w.published=1) AS examples FROM patterns p WHERE 1=1"
    params=[]
    if q.strip():
        sql += " AND (p.name LIKE ? OR p.description LIKE ? OR p.guidance LIKE ?)"
        params += [f"%{q.strip()}%"]*3
    if family: sql+=" AND p.family=?";params.append(family)
    sql+=" ORDER BY p.id"
    return {"items":rows(sql,params)}


def required_admin_token(x_admin_token: str | None=Header(default=None)):
    expected=os.getenv("ATLAS_ADMIN_TOKEN")
    if not expected:
        raise HTTPException(503,"Curator write API disabled: set ATLAS_ADMIN_TOKEN to enable.")
    from hmac import compare_digest
    if not x_admin_token or not compare_digest(x_admin_token,expected):
        raise HTTPException(401,"Invalid curator token")
    return True


class EntryBase(BaseModel):
    slug: str=Field(min_length=3,max_length=90,pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    @field_validator("slug")
    @classmethod
    def clean_slug(cls,value): return value.lower()


class WebsiteCreate(EntryBase):
    name: str=Field(min_length=2,max_length=100)
    industry: str=Field(min_length=2,max_length=60)
    business_model: str=""
    style: str="Editorial"
    palette: str="sand"
    tagline: str=""
    hero_title: str=""
    hero_kicker: str=""
    description: str=""
    design_note: str=""
    visual: str="blocks"
    featured: int=0
    reference_type: Literal["Original Study","Live Website","Template","Design Concept"]="Original Study"
    source_url: str | None=None
    image_url: str | None=None
    published: int=1

    @field_validator("source_url","image_url")
    @classmethod
    def validate_urls(cls,value):
        if value is None or value=="": return None
        parsed=urlparse(value)
        if parsed.scheme not in ("https","http") or not parsed.netloc:
            raise ValueError("URL must be a valid http(s) address")
        return value


class SectionCreate(EntryBase):
    website_slug: str
    type: str
    title: str
    layout: str
    summary: str=""
    principle: str=""
    pitfall: str=""
    content_fit: str=""
    visual: str="blocks"
    palette: str="sand"
    preview_caption: str=""
    badge: str="Original Study"
    featured: int=0
    source_url: str | None=None
    image_url: str | None=None
    published: int=1

    @field_validator("source_url","image_url")
    @classmethod
    def validate_urls(cls,value):
        if not value: return None
        parsed=urlparse(value)
        if parsed.scheme not in ("https","http") or not parsed.netloc: raise ValueError("Invalid URL")
        return value


def insert(table:Literal["websites","sections"], obj:dict):
    cols=','.join(obj)
    vals=','.join('?' for _ in obj)
    try:
        with db() as con:
            con.execute(f"INSERT INTO {table} ({cols}) VALUES ({vals})", tuple(obj.values()))
    except sqlite3.IntegrityError as exc:
        raise HTTPException(409,f"Record invalid or duplicate: {exc}") from exc
    return {"ok":True,"slug":obj["slug"]}


@app.post("/api/admin/websites",dependencies=[Depends(required_admin_token)],status_code=201)
def add_website(item:WebsiteCreate):
    if item.reference_type != "Original Study":
        raise HTTPException(409,"Submit third-party references through /api/admin/intake for rights and editorial review")
    if item.image_url or item.source_url:
        raise HTTPException(409,"Original studies must not link external images or sources through the direct authoring API")
    return insert("websites",item.model_dump())


@app.post("/api/admin/sections",dependencies=[Depends(required_admin_token)],status_code=201)
def add_section(item:SectionCreate):
    parent = single("SELECT reference_type FROM websites WHERE slug=? AND published=1", (item.website_slug,))
    if not parent: raise HTTPException(404,"Parent website not found")
    if parent["reference_type"] != "Original Study":
        raise HTTPException(409,"Real website section anatomy requires the separate reviewed page-annotation workflow")
    if item.image_url or item.source_url:
        raise HTTPException(409,"Original section entries cannot use third-party sources through direct authoring")
    return insert("sections",item.model_dump())


@app.delete("/api/admin/{kind}/{slug}",dependencies=[Depends(required_admin_token)])
def unpublish(kind:Literal["websites","sections"],slug:str):
    with db() as con:
        res=con.execute(f"UPDATE {kind} SET published=0 WHERE slug=?",(slug,))
        if res.rowcount==0: raise HTTPException(404,"Item not found")
    return {"ok":True,"slug":slug,"published":False}


from app.intake import register_intake
register_intake(app, db, required_admin_token, DB_FILE.parent)


@app.get("/operations")
def operations_page(): return FileResponse(STATIC / "operations.html")


@app.get("/admin")
def admin_page(): return FileResponse(STATIC / "admin.html")


@app.get("/{full_path:path}",include_in_schema=False)
def frontend(full_path:str):
    if full_path.startswith(("api/", "media/")): raise HTTPException(404,"Not found")
    return FileResponse(STATIC / "index.html")
