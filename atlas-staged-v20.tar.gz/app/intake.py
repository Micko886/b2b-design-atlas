"""Editorial intake workflow for permission-conscious third-party references.

Public listing requires an explicit curator approval. Uploaded screenshots require
rights documentation. This module NEVER fetches third-party URLs.
"""
from __future__ import annotations

import hashlib
import io
import ipaddress
import json
import re
import sqlite3
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from PIL import Image, ImageOps, UnidentifiedImageError
from pydantic import BaseModel, Field, field_validator

STATES = ("draft", "in_review", "approved", "published", "rejected", "archived")
RIGHTS = ("pending", "granted", "denied", "revoked")
URL_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
MAX_UPLOAD = 8 * 1024 * 1024


def public_url(value: str) -> str:
    """Validate a *stored link*; no HTTP request is performed."""
    parsed = urlsplit(value)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Source must be a public https URL without credentials")
    host = parsed.hostname.strip(".").lower()
    if host == "localhost" or host.endswith((".local", ".localhost", ".internal", ".test")) or "." not in host:
        raise ValueError("Local or private hosts are not acceptable source references")
    try:
        if not ipaddress.ip_address(host).is_global:
            raise ValueError("Private or non-global IP address is not permitted")
    except ValueError as exc:
        if "not permitted" in str(exc):
            raise
    if parsed.port and parsed.port != 443:
        raise ValueError("Only the standard HTTPS port is accepted")
    return value


class IntakeCreate(BaseModel):
    slug: str = Field(min_length=3, max_length=90, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    name: str = Field(min_length=2, max_length=120)
    source_url: str = Field(min_length=12, max_length=1000)
    reference_type: str = Field(default="Live Website", pattern=r"^(Live Website|Template|Design Concept)$")
    industry: str = Field(default="Manufacturing", max_length=70)
    business_model: str = Field(default="", max_length=160)
    style: str = Field(default="Editorial", max_length=80)
    tagline: str = Field(default="", max_length=180)
    hero_title: str = Field(default="", max_length=200)
    description: str = Field(default="", max_length=3000)
    design_note: str = Field(default="", max_length=4000)
    rights_holder: str = Field(default="", max_length=250)
    rights_status: str = Field(default="pending", pattern=r"^(pending|granted|denied|revoked)$")
    rights_evidence: str = Field(default="", max_length=3000)
    attribution: str = Field(default="", max_length=350)
    submission_note: str = Field(default="", max_length=3000)

    @field_validator("source_url")
    @classmethod
    def valid_source(cls, v):
        return public_url(v)


class IntakeEdit(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=120)
    source_url: str | None = Field(default=None, min_length=12, max_length=1000)
    industry: str | None = Field(default=None, max_length=70)
    business_model: str | None = Field(default=None, max_length=160)
    style: str | None = Field(default=None, max_length=80)
    tagline: str | None = Field(default=None, max_length=180)
    hero_title: str | None = Field(default=None, max_length=200)
    description: str | None = Field(default=None, max_length=3000)
    design_note: str | None = Field(default=None, max_length=4000)
    rights_holder: str | None = Field(default=None, max_length=250)
    rights_status: str | None = Field(default=None, pattern=r"^(pending|granted|denied|revoked)$")
    rights_evidence: str | None = Field(default=None, max_length=3000)
    attribution: str | None = Field(default=None, max_length=350)
    submission_note: str | None = Field(default=None, max_length=3000)

    @field_validator("source_url")
    @classmethod
    def valid_source(cls, v):
        return public_url(v) if v else v


class Review(BaseModel):
    decision: str = Field(pattern=r"^(approve|reject|reopen)$")
    note: str = Field(min_length=10, max_length=3000)
    reviewer: str = Field(min_length=2, max_length=100)


class ManualCheck(BaseModel):
    note: str = Field(min_length=15, max_length=1200)
    reviewer: str = Field(min_length=2, max_length=100)


class Takedown(BaseModel):
    reason: str = Field(min_length=10, max_length=3000)
    reviewer: str = Field(min_length=2, max_length=100)


def register_intake(app, db, admin_auth, data_dir: Path):
    router = APIRouter(prefix="/api/admin/intake", dependencies=[Depends(admin_auth)], tags=["Editorial intake"])
    media = data_dir / "media"
    media.mkdir(parents=True, exist_ok=True)

    def get(con, id):
        row = con.execute("SELECT * FROM reference_intake WHERE id=?", (id,)).fetchone()
        if row is None:
            raise HTTPException(404, "Intake record not found")
        return dict(row)

    def log(con, id, action, detail):
        con.execute("INSERT INTO intake_audit (candidate_id,action,detail) VALUES (?,?,?)", (id, action, detail[:3000]))

    def delete_local_asset(candidate):
        """Remove inaccessible/revoked local evidence image (never arbitrary filesystem paths)."""
        url = candidate.get("screenshot_path") or ""
        name = url.removeprefix("/media/")
        if url.startswith("/media/") and re.fullmatch(r"ref-\d+-[a-f0-9]{18}\.webp", name):
            (media / name).unlink(missing_ok=True)

    def unpublish(con, candidate, action):
        if candidate["published_slug"]:
            con.execute("UPDATE websites SET published=0 WHERE slug=?", (candidate["published_slug"],))
        log(con, candidate["id"], action, "Public reference unpublished")

    def require_screenshot_rights(record):
        if not all((record["rights_status"] == "granted", record["rights_holder"].strip(),
                    record["rights_evidence"].strip(), record["attribution"].strip())):
            raise HTTPException(409, "Screenshot rights require granted status, rights holder, evidence and attribution")

    with db() as con:
        con.executescript("""
          CREATE TABLE IF NOT EXISTS reference_intake (
            id INTEGER PRIMARY KEY AUTOINCREMENT,slug TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,source_url TEXT NOT NULL UNIQUE,reference_type TEXT NOT NULL,
            industry TEXT NOT NULL,business_model TEXT NOT NULL DEFAULT '',
            style TEXT NOT NULL DEFAULT 'Editorial',tagline TEXT NOT NULL DEFAULT '',
            hero_title TEXT NOT NULL DEFAULT '',description TEXT NOT NULL DEFAULT '',
            design_note TEXT NOT NULL DEFAULT '',rights_holder TEXT NOT NULL DEFAULT '',
            rights_status TEXT NOT NULL DEFAULT 'pending',rights_evidence TEXT NOT NULL DEFAULT '',
            attribution TEXT NOT NULL DEFAULT '',submission_note TEXT NOT NULL DEFAULT '',
            source_checked_at TEXT,source_check_note TEXT NOT NULL DEFAULT '',
            screenshot_path TEXT,screenshot_sha256 TEXT,screenshot_at TEXT,
            status TEXT NOT NULL DEFAULT 'draft',reviewer TEXT NOT NULL DEFAULT '',
            review_note TEXT NOT NULL DEFAULT '',reviewed_at TEXT,published_slug TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
          );
          CREATE TABLE IF NOT EXISTS intake_audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,candidate_id INTEGER NOT NULL REFERENCES reference_intake(id),
            action TEXT NOT NULL,detail TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
          );
          CREATE INDEX IF NOT EXISTS idx_intake_status ON reference_intake(status);
        """)

    @router.get("")
    def list_intake(status: str = "", q: str = "", limit: int = Query(100, ge=1, le=200)):
        sql = "SELECT * FROM reference_intake WHERE 1=1"
        params = []
        if status:
            if status not in STATES:
                raise HTTPException(422, "Unknown status")
            sql += " AND status=?"; params.append(status)
        if q.strip():
            sql += " AND (name LIKE ? OR source_url LIKE ? OR slug LIKE ?)"
            params.extend([f"%{q.strip()}%"] * 3)
        sql += " ORDER BY updated_at DESC,id DESC LIMIT ?"; params.append(limit)
        with db() as con:
            items = [dict(r) for r in con.execute(sql, params)]
            summary = {r["status"]: r["n"] for r in con.execute("SELECT status,COUNT(*) AS n FROM reference_intake GROUP BY status")}
        return {"items": items, "summary": summary}

    @router.post("", status_code=201)
    def create(item: IntakeCreate):
        values = item.model_dump()
        with db() as con:
            try:
                con.execute(f"INSERT INTO reference_intake ({','.join(values)}) VALUES ({','.join('?' for _ in values)})", tuple(values.values()))
            except sqlite3.IntegrityError:
                raise HTTPException(409, "Intake slug or source URL already exists")
            id = con.execute("SELECT last_insert_rowid()").fetchone()[0]
            log(con, id, "created", "Candidate registered; not publicly visible")
            return {"ok": True, "id": id, "status": "draft"}

    @router.get("/{id}")
    def detail(id: int):
        with db() as con:
            candidate = get(con, id)
            candidate["audit"] = [dict(x) for x in con.execute("SELECT action,detail,created_at FROM intake_audit WHERE candidate_id=? ORDER BY id DESC", (id,))]
        return candidate

    @router.patch("/{id}")
    def edit(id: int, item: IntakeEdit):
        changes = item.model_dump(exclude_unset=True)
        if not changes: raise HTTPException(422, "Nothing to update")
        with db() as con:
            record = get(con, id)
            if record["status"] in ("rejected", "archived"):
                raise HTTPException(409, "Reopen this record before editing")
            if "source_url" in changes and changes["source_url"] != record["source_url"]:
                changes.update(source_checked_at=None, source_check_note="")
                if record["status"] in ("approved", "published"):
                    raise HTTPException(409, "Reopen an approved record before changing its source")
            if record["status"] == "published" and any(k not in {"rights_status", "rights_evidence", "rights_holder", "attribution"} for k in changes):
                raise HTTPException(409, "Reopen an approved reference before changing editorial metadata")
            updated_rights = {k: changes.get(k, record[k]) for k in ("rights_status", "rights_holder", "rights_evidence", "attribution")}
            rights_revoked = bool(record["screenshot_path"] and not (
                updated_rights["rights_status"] == "granted" and
                all(str(updated_rights[k]).strip() for k in ("rights_holder", "rights_evidence", "attribution"))
            ))
            if record["screenshot_path"] and rights_revoked:
                changes["screenshot_path"] = None
                changes["screenshot_sha256"] = None
            if record["status"] == "published" and any(k in changes for k in (
                "rights_status", "rights_holder", "rights_evidence", "attribution"
            )):
                # Any rights-document change must be reviewed again before the reference is public.
                unpublish(con, record, "rights_changed")
                changes["status"] = "draft"
            if record["status"] == "approved":
                changes["status"] = "draft"
            cols = ", ".join(f"{k}=?" for k in changes)
            try:
                con.execute(f"UPDATE reference_intake SET {cols},updated_at=CURRENT_TIMESTAMP WHERE id=?", (*changes.values(), id))
            except sqlite3.IntegrityError:
                raise HTTPException(409, "Source URL duplicates an existing entry")
            log(con, id, "edited", ", ".join(changes.keys()))
        if rights_revoked:
            delete_local_asset(record)
        return {"ok": True, "id": id}

    @router.post("/{id}/verify")
    def verify(id: int, body: ManualCheck):
        with db() as con:
            record = get(con, id)
            if record["status"] not in ("draft", "in_review"):
                raise HTTPException(409, "Only draft/in-review references can be checked")
            con.execute("UPDATE reference_intake SET source_checked_at=CURRENT_TIMESTAMP,source_check_note=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (body.note, id))
            log(con, id, "source_manual_check", f"{body.reviewer}: {body.note}")
        return {"ok": True, "manual_check": True}

    @router.post("/{id}/submit")
    def submit(id: int):
        with db() as con:
            record = get(con, id)
            if record["status"] != "draft":
                raise HTTPException(409, "Only draft references can be submitted")
            con.execute("UPDATE reference_intake SET status='in_review',updated_at=CURRENT_TIMESTAMP WHERE id=?", (id,))
            log(con, id, "submitted", "Moved into editorial review queue")
        return {"ok": True, "status": "in_review"}

    @router.post("/{id}/review")
    def review(id: int, body: Review):
        with db() as con:
            record = get(con, id)
            decision = body.decision
            if decision == "approve":
                if record["status"] != "in_review":
                    raise HTTPException(409, "Only in-review references can be approved")
                if not record["source_checked_at"]:
                    raise HTTPException(409, "A human source verification note is required before approval")
                if len(record["description"].strip()) < 40 or len(record["design_note"].strip()) < 40:
                    raise HTTPException(409, "Approval requires a meaningful description and design analysis (40+ characters each)")
                if record["rights_status"] in ("denied", "revoked"):
                    raise HTTPException(409, "Rights denied/revoked")
                if record["screenshot_path"]:
                    require_screenshot_rights(record)
                new_status = "approved"
            elif decision == "reject":
                if record["status"] not in ("in_review", "draft", "approved"):
                    raise HTTPException(409, "Cannot reject this status")
                new_status = "rejected"
            else:
                if record["status"] not in ("rejected", "approved", "archived"):
                    raise HTTPException(409, "Only rejected, approved or archived records can be reopened")
                if record["status"] == "archived":
                    # Reopening cannot restore a revoked license.
                    new_status = "draft"
                else:
                    new_status = "draft"
            con.execute("UPDATE reference_intake SET status=?,reviewer=?,review_note=?,reviewed_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?", (new_status, body.reviewer, body.note, id))
            log(con, id, f"review_{decision}", f"{body.reviewer}: {body.note}")
        return {"ok": True, "status": new_status}

    @router.post("/{id}/screenshot")
    async def screenshot(id: int, file: UploadFile = File(...)):
        with db() as con:
            record = get(con, id)
            if record["status"] not in ("draft", "in_review"):
                raise HTTPException(409, "Screenshot changes require draft or in-review status")
            require_screenshot_rights(record)
        contents = await file.read(MAX_UPLOAD + 1)
        if len(contents) > MAX_UPLOAD:
            raise HTTPException(413, "Max upload size is 8 MiB")
        if not contents:
            raise HTTPException(422, "Empty screenshot")
        try:
            with Image.open(io.BytesIO(contents)) as original:
                if original.format not in ("PNG", "JPEG", "WEBP"):
                    raise ValueError("Only PNG, JPEG and WebP images are supported")
                if original.width * original.height > 40_000_000:
                    raise ValueError("Image pixel count exceeds limit")
                pic = ImageOps.exif_transpose(original).convert("RGB")
                pic.thumbnail((1600, 3600), Image.Resampling.LANCZOS)
                output = io.BytesIO()
                pic.save(output, format="WEBP", quality=84, method=5)
        except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError) as exc:
            raise HTTPException(422, f"Unsupported screenshot: {exc}") from exc
        digest = hashlib.sha256(contents).hexdigest()
        file_name = f"ref-{id}-{digest[:18]}.webp"
        path = media / file_name
        path.write_bytes(output.getvalue())
        url = f"/media/{file_name}"
        with db() as con:
            record = get(con, id)
            require_screenshot_rights(record)
            con.execute("UPDATE reference_intake SET screenshot_path=?,screenshot_sha256=?,screenshot_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?", (url, digest, id))
            log(con, id, "screenshot_uploaded", f"Local normalized WebP: {file_name}; SHA256 {digest}")
        if record["screenshot_path"] and record["screenshot_path"] != url:
            delete_local_asset(record)
        return {"ok": True, "image_url": url, "sha256": digest}

    @router.post("/{id}/publish")
    def publish(id: int):
        with db() as con:
            record = get(con, id)
            if record["status"] != "approved":
                raise HTTPException(409, "Reference must be approved before publication")
            if not record["source_checked_at"]:
                raise HTTPException(409, "Manual source verification required")
            if record["rights_status"] in ("denied", "revoked"):
                raise HTTPException(409, "Cannot publish denied or revoked rights")
            if record["screenshot_path"]:
                require_screenshot_rights(record)
            elif record["rights_status"] == "granted":
                # No local image is allowed to be faked. A metadata-only card is clearly labeled.
                pass
            if record["published_slug"] is None and con.execute("SELECT 1 FROM websites WHERE slug=?", (record["slug"],)).fetchone():
                raise HTTPException(409, "Website slug already exists in public catalog")
            values = {
                "slug": record["slug"], "name": record["name"], "industry": record["industry"],
                "business_model": record["business_model"], "style": record["style"], "palette": "sand",
                "tagline": record["tagline"], "hero_title": record["hero_title"],
                "hero_kicker": "CURATED REFERENCE", "description": record["description"],
                "design_note": record["design_note"], "visual": "blocks", "featured": 0,
                "reference_type": record["reference_type"], "source_url": record["source_url"],
                "image_url": record["screenshot_path"], "published": 1,
            }
            if record["published_slug"]:
                con.execute("UPDATE websites SET " + ",".join(k+"=?" for k in values if k!="slug") + " WHERE slug=?", (*[v for k,v in values.items() if k!="slug"], record["published_slug"]))
            else:
                con.execute("INSERT INTO websites (" + ",".join(values) + ") VALUES (" + ",".join("?" for _ in values) + ")", tuple(values.values()))
            con.execute("UPDATE reference_intake SET status='published',published_slug=slug,updated_at=CURRENT_TIMESTAMP WHERE id=?", (id,))
            log(con, id, "published", "Live reference published with local screenshot" if record["screenshot_path"] else "Metadata-only public listing; no screenshot")
        return {"ok": True, "status": "published", "public_path": "/websites"}

    @router.post("/{id}/takedown")
    def takedown(id: int, body: Takedown):
        with db() as con:
            record = get(con, id)
            if record["status"] == "archived":
                raise HTTPException(409, "Reference already archived")
            unpublish(con, record, "takedown")
            con.execute("UPDATE reference_intake SET status='archived',rights_status='revoked',screenshot_path=NULL,screenshot_sha256=NULL,reviewer=?,review_note=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (body.reviewer, body.reason, id))
            log(con, id, "takedown_reason", f"{body.reviewer}: {body.reason}")
        delete_local_asset(record)
        return {"ok": True, "status": "archived", "public": False}

    app.include_router(router)

    @app.get("/media/{name}", include_in_schema=False)
    def local_media(name: str):
        if not re.fullmatch(r"ref-\d+-[a-f0-9]{18}\.webp", name):
            raise HTTPException(404, "Asset unavailable")
        path = media / name
        if not path.is_file():
            raise HTTPException(404, "Asset unavailable")
        return FileResponse(path, media_type="image/webp", headers={"Cache-Control": "public, max-age=300", "X-Content-Type-Options": "nosniff"})
