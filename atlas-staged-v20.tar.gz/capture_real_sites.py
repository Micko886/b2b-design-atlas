"""Capture actual public pages using Chromium in CI.

This is an editorial reference capture, not a site replica. Redirects and pages
requiring authentication or bot challenges are not bypassed. Failures are logged.
"""
import asyncio
import io
import json
import re
import datetime
from pathlib import Path
from urllib.parse import urlsplit
from PIL import Image, ImageStat
from playwright.async_api import async_playwright

BASE=Path(__file__).parent
CATALOG=json.loads((BASE/'app/source_index.json').read_text())
OUT=BASE/'screenshots'
OUT.mkdir(exist_ok=True)
STAMP=datetime.datetime.now(datetime.timezone.utc).isoformat()

async def capture(browser, sem, kind, item):
    ident=item['id']
    url=item['url']
    path=OUT/kind/(ident+'.webp')
    async with sem:
        page=await browser.new_page(viewport={'width':1440,'height':920},device_scale_factor=1,locale='en-US',color_scheme='light',ignore_https_errors=True)
        try:
            response=await page.goto(url,wait_until='domcontentloaded',timeout=27000)
            if not response or response.status>=400:
                raise RuntimeError('HTTP '+str(response.status if response else 'no response'))
            await page.wait_for_timeout(1600)
            title=(await page.title())[:140]
            page_content=(await page.locator('body').inner_text(timeout=7000))[:450]
            if re.search(r'Access Denied|Just a moment|Checking your browser|Robot Check|Enable JavaScript|CAPTCHA|Forbidden', title+' '+page_content, re.I):
                raise RuntimeError('Browser challenge or access restriction')
            # Handle visible first-party cookie panels normally. Prefer opt-out.
            # Some CMPs render late or inside frames, so retry briefly and look
            # in each frame. No overlays are hidden using injected styles.
            cookie_choices = [
                re.compile(r"^(reject (all|optional)|decline (all|optional)|only necessary|necessary only|essential only|reject all cookies)$", re.I),
                re.compile(r"^(allow all|accept all|accept all cookies|accept cookies|accept|agree and continue|agree|got it|ok)$", re.I)
            ]
            await page.wait_for_timeout(900)
            dismissed = False
            for _ in range(3):
                for pattern in cookie_choices:
                    for frame in page.frames:
                        if dismissed:
                            break
                        try:
                            button = frame.get_by_role('button', name=pattern).first
                            if await button.count() and await button.is_visible(timeout=800):
                                await button.click(timeout=1700)
                                dismissed = True
                                await page.wait_for_timeout(650)
                        except Exception:
                            continue
                    if dismissed:
                        break
                if dismissed:
                    break
                await page.wait_for_timeout(750)
            # Wait for images and fonts where available before taking the viewport.
            try:
                await page.evaluate("document.fonts.ready")
            except Exception:
                pass
            await page.wait_for_timeout(450)
            data=await page.screenshot(type='png',full_page=False,animations='disabled',timeout=13000)
            image=Image.open(io.BytesIO(data)).convert('RGB')
            # reject fully blank/errors without pretending a real design capture exists
            st=ImageStat.Stat(image.resize((80,50)))
            if max(st.stddev)<11:
                raise RuntimeError('Low-information or blank page')
            path.parent.mkdir(parents=True,exist_ok=True)
            image.save(path,format='WEBP',quality=82,method=5)
            print('OK',kind,ident,response.status,title[:58],path.stat().st_size,flush=True)
            return {'id':ident,'type':kind,'url':url,'resolved_url':page.url,'title':title,'status':'captured','captured_at':STAMP,'path':str(path.relative_to(BASE))}
        except Exception as exc:
            print('SKIP',kind,ident,str(exc)[:150],flush=True)
            return {'id':ident,'type':kind,'url':url,'status':'not_captured','error':str(exc)[:220],'checked_at':STAMP}
        finally:
            await page.close()

async def main():
    tasks=[]
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        sem=asyncio.Semaphore(3)
        for item in CATALOG['sites']:tasks.append(capture(browser,sem,'sites',item))
        for item in CATALOG['notes']:tasks.append(capture(browser,sem,'notes',item))
        results=await asyncio.gather(*tasks)
        await browser.close()
    (OUT/'capture-log.json').write_text(json.dumps({'capture_time':STAMP,'results':results},indent=2),encoding='utf-8')
    success=sum(x['status']=='captured' for x in results)
    print(f'CAPTURE REPORT {success}/{len(results)} saved. Failures remain unpublished.',flush=True)

if __name__=='__main__':asyncio.run(main())
