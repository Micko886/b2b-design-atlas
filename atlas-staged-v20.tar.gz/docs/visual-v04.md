# B2B Atlas / V0.4 visual redesign notes

## Positioning
An editorial **visual gallery of real B2B websites**, not an AI template generator, an industrial directory, or a collection of hypothetical visuals.

## Design decisions
- Bright white canvas with deliberate whitespace; neutral 1-pixel borders and simple dark typography.
- Real screenshot first: large framed viewport images and a responsive visual grid. No geometry placeholders or synthetic branded examples.
- Homepage begins with a compact, informative positioning statement then immediately shows two real captures at scale.
- Websites and Sections each have intent-specific search, filter chips, optional density control, and meaningful result counts.
- Every case has its own deep-linkable URL and reading layout: actual screenshot, source link, editorial notes, related pages, saved reference and project-board action.
- Patterns are grounded in the real captured page library, not generated diagrams.
- Saved and Board remain browser-local in preview; export supports Markdown.

## Current content limitations
- 10 sites and 21 source-page screenshots captured, based on live verified successful images; inaccessible sites are excluded.
- The page screenshots are viewport images, not separately cropped individual section screenshots. Call them page references, not extracted modules.
- Some original site cookie overlays may still be visible depending on CMP behavior. Screenshot capture workflow tries normal on-page opt-out first; blocked pages remain excluded.
- Capture metadata and rights requests should stay linked to original sources; this is editorial reference use, not licensed reproduction or a source-code marketplace.
- Full screenshot image pixels are owned by their respective source websites.

## Acceptance checks
- UI JS syntax and backend tests pass.
- Home, websites, sections, patterns, saved, board and deep links return 200.
- Real-site and page screenshot URLs resolve and decode to WebP.
- Browser: verify layout, keyboard search, gallery filters, card click, detail save, board export and mobile horizontal overflow.
