from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app

ROOT=Path(__file__).resolve().parents[1]
client=TestClient(app)

def test_curated_editorial_shell_and_assets():
    html=client.get('/').text
    assert 'atlas-v07.css' in html
    assert 'favicon-v07.svg' in html
    assert 'class="logo-type"' in html
    css=client.get('/assets/atlas-v07.css')
    assert css.status_code==200 and len(css.content)>60000
    assert '.curation-grid' in css.text and '.taxonomy-grid' in css.text
    assert '.archive-masthead' in css.text

def test_curated_home_and_catalog_browsing_source():
    js=client.get('/assets/atlas-v05.js').text
    assert 'Worth a<br><span>closer look.</span>' in js
    assert 'curation-grid' in js
    assert 'taxonomy-grid' in js
    assert 'archive-category-list' in js
    assert 'module-showcase-grid' in js
    assert 'data-filter' in js and 'data-save' in js and 'data-board-add' in js
    assert "fetch('/api/source-library')" in js

def test_real_images_and_all_pages_still_served():
    assert client.get('/screenshots/sites/fictiv.webp').status_code == 200
    for path in ['/','/websites','/sections','/patterns','/collections','/board','/websites/fictiv','/sections/gensler-15']:
        assert client.get(path).status_code==200
