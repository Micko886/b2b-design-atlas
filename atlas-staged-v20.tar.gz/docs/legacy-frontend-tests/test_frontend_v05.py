from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app

BASE = Path(__file__).resolve().parents[1]
client = TestClient(app)


def test_v05_editorial_site_shell():
    r = client.get('/')
    assert r.status_code == 200
    for piece in ['atlas-v07.css', 'atlas-v05.js', 'main-content', 'class="logo-type"']:
        assert piece in r.text


def test_v05_routes():
    for path in ['/', '/websites', '/sections', '/websites/fictiv', '/sections/gensler-15', '/patterns', '/board', '/collections']:
        r = client.get(path)
        assert r.status_code == 200, path
        assert 'id="main-content"' in r.text


def test_v05_app_is_real_source_only():
    text = (BASE / 'static/assets/atlas-v05.js').read_text(encoding='utf-8')
    for snippet in ["fetch('/api/source-library')", 'screenshot_url', "filter(x=>x.screenshot_url", 'data-image', 'data-filter', 'data-export']:
        assert snippet in text, snippet
    assert 'browser-toolbar' not in text


def test_v05_assets_load():
    for path, part in [('/assets/atlas-v05.js', 'javascript'), ('/assets/atlas-v05.css','css'),('/assets/favicon-v05.svg','image/svg')]:
        r=client.get(path)
        assert r.status_code == 200
        assert part in r.headers['content-type']
        assert len(r.content)>100
