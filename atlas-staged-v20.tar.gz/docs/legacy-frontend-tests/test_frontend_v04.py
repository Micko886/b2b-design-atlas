from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)
BASE = Path(__file__).parents[1]


def test_real_site_gallery_shell():
    response = client.get('/')
    assert response.status_code == 200
    assert 'atlas-v05.js' in response.text
    assert 'atlas-v07.css' in response.text
    assert 'B2B ATLAS' in response.text
    assert 'Thumbnail diagrams are editorial interpretations' not in response.text


def test_detail_routes_and_sections_have_spa_fallback():
    for url in ('/websites/fictiv', '/sections/fictiv-0', '/websites', '/sections', '/patterns', '/board', '/collections'):
        response = client.get(url)
        assert response.status_code == 200
        assert 'id="main-content"' in response.text


def test_frontend_js_uses_real_capture_api():
    script = (BASE / 'static/assets/atlas-v04.js').read_text('utf-8')
    assert "fetch('/api/source-library')" in script
    assert 'site.screenshot_url' in script
    assert "'site:'" in script
    assert 'Legacy study – not a real website screenshot' not in script
    assert 'data-board-add' in script


def test_new_assets_are_served():
    for path, content_type in (('/assets/atlas-v04.css', 'text/css'), ('/assets/atlas-v04.js', 'javascript')):
        response = client.get(path)
        assert response.status_code == 200
        assert len(response.content) > 10000
        assert content_type in response.headers['content-type']
