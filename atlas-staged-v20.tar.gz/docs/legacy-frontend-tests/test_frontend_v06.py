from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app

BASE=Path(__file__).resolve().parents[1]
client=TestClient(app)

def test_quiet_gallery_assets():
    html=client.get('/').text
    assert '/assets/atlas-v07.css' in html
    assert '/assets/favicon-v07.svg' in html
    assert 'Instrument+Serif' not in html
    assert 'logo-shape' not in html
    css=client.get('/assets/atlas-v07.css')
    assert css.status_code==200 and len(css.content)>10000
    assert '--accent:#344e5a' in css.text
    assert 'prefers-reduced-motion' in css.text

def test_browse_real_pages():
    js=client.get('/assets/atlas-v05.js').text
    assert 'Worth a<br><span>closer look.</span>' in js
    for v in ['data-nav','/api/source-library','hero-search','data-board-add','case-card','curation-grid']:
        assert v in js
    for route in ['/','/websites','/sections','/patterns','/board','/websites/fictiv']:
        assert client.get(route).status_code==200
