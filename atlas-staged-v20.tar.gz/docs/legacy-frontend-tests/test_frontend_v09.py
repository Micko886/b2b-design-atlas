import json
from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app

ROOT=Path(__file__).resolve().parents[1]
client=TestClient(app)

def test_v09_masthead_and_assets():
    page=client.get('/')
    assert page.status_code == 200
    assert 'atlas-v09.css' in page.text and 'atlas-v09.js' in page.text
    for url in ['/assets/atlas-v09.css','/assets/atlas-v09.js']:
        response=client.get(url)
        assert response.status_code==200 and len(response.content)>15000

def test_v09_functional_routes():
    for p in ['/','/websites','/sections','/websites/fictiv','/sections/fictiv-capability-hero', '/board','/collections']:
        assert client.get(p).status_code==200

def test_v09_real_crops_endpoint():
    result=client.get('/api/module-library')
    assert result.status_code==200
    js=result.json()
    assert js['source_policy'].startswith('Only reviewed pixel crops')
    assert js['total']==16
    assert all(x['screenshot_url'].startswith('/screenshots/modules/') for x in js['modules'])
    assert all(client.get(x['screenshot_url']).status_code==200 for x in js['modules'])

def test_v09_crops_are_literal_regions_from_full_screenshot():
    from PIL import Image
    catalog=json.loads((ROOT/'app/module_catalog.json').read_text())
    assert len(catalog)==16
    for sample in catalog:
        src=ROOT/'screenshots'/'notes'/f"{sample['page_id']}.webp"
        crop=ROOT/'screenshots'/'modules'/sample['image_file']
        src_im=Image.open(src);cropped=Image.open(crop)
        x0,y0,x1,y1=sample['crop_px']
        assert cropped.size==(x1-x0,y1-y0)
        assert y1<=src_im.height

def test_v09_js_uses_real_source_and_module_apis():
    js=(ROOT/'static/assets/atlas-v09.js').read_text()
    for key in ["fetch('/api/source-library')","fetch('/api/module-library')",'galleryCard','a9-discovery-grid','a9-section-grid','data-compare','data-board-add','data-save','/websites']:
        assert key in js
    assert 'AI concept study' not in js

def test_public_ops_not_exposed_as_static_demo():
    assert client.get('/api/health').status_code==200
    assert client.get('/api/source-library').status_code==200
