# B2B ATLAS v0.5 — Editorial Gallery Design System

## Product presentation
This is a public, image-led research library built around captured third-party company websites. The visual experience must serve actual reference images and business context, not generic SaaS visuals.

## Design tokens
- Background: `#FFFFFF`; section background: `#F5F4F0`; footer: `#F9F8F6`
- Ink: `#181B1A`; secondary: `#70726F`; rules: `#E8E7E3`
- Accent: `#E85535`, limited to navigation indicators, key controls and editorial type accents
- Real website thumbnails remain unaltered and retain their individual brand colors
- Display: DM Sans 700/800, a sparing Instrument Serif Italic accent; fallback system fonts
- Card: 11px corner radius, soft 8px frame and natural screenshot ratio 16:10
- Interactive: focus-visible, hover elevation, responsive gallery and persistent saved/board state

## Page hierarchy
1. Home: visible captured feature immediately, prominent scoped search, industry links and three-column image gallery; black editorial learning block creates a single contrast break.
2. Websites: browsing-first archive with search, sector chips, dense grid and compact layout switch.
3. Pages & sections: real source *pages*, not falsely labeled isolated section crops; page-type and industry filters.
4. Reference detail: visual screenshot first, source link, design analysis, context sidebar, related pages, zoom and board save.
5. Patterns: illustrated through captured real references, not fake generated design concepts.
6. Saved and Board: personal workflow backed by browser localStorage, export Markdown. No misleading account claims.

## Data integrity
- Public catalog uses `/api/source-library` and only displays items with deployed screenshots.
- Source screenshot attribution is included. These are visual research captures, not code templates.
- Failed URL captures are omitted rather than replaced with invented artwork.
- Existing screenshot rights/curator API preserved.

## Known constraints
- The screenshot archive currently has about 10 captured sites and 21 page captures.
- Page captures are not yet precise DOM-bound section crops. This distinction must remain explicit.
- Browser-local collections do not sync between devices. Render free hosting may sleep, and SQLite is ephemeral.
- Production commercial licensing and legal/rights review remain necessary before expanded external promotion.
