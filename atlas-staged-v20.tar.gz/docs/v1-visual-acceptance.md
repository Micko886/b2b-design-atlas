# V1.0 visual quality criteria

Design intent: replace repeated branded marketing / editorial modules with a product-grade exploration tool. Source photographs and site screenshots—not interface ornament—carry primary visual interest.

**Reference:** Land-book for image treatment, Godly for discovery browsing, SaaSFrame for purposeful filters and page search, regards.design for section study, DesignforB2B for category boundaries. These are directional references, not cloned markup or CSS.

## Desktop
- Home: search and real website visuals visible within first fold at 1440 × 900; screenshot image text legible, no arbitrary crops into headline.
- Websites: persistent filter rail, screenshot tiles with meaningful metadata, gallery/compact modes.
- Sections: real cropped modules only; category filters and two-item compare.
- Detail: 70/30 media vs source metadata, navigable source URL, observations and save.
- No broken images, visual placeholders, fake websites, horizontal overflow, or scripting errors.

## Mobile
- Search at top; content starts without a full-screen splash.
- Menu closed by default; tap to open and close.
- Side categories become horizontal, swipeable filter groups.
- Gallery responsive; compare modal fits screen and permits scrolling.
- Controls remain at least 34 px in size where possible; all interactive elements accessible via keyboard.

## Trust
- 10 real website captures displayed, 16 independently selected real page regions.
- Every reference links to original source and gives a takedown route.
- Source screenshots are not licensed templates. Do not assert improvements in conversion or SEO without evidence.

### Post-QA corrective changes
- Removed the hidden comparison tray from the first paint: its previously offscreen frame appeared at the bottom of screenshots.
- Reduced homepage opening copy size and height so real references enter the first viewport sooner.
- Removed duplicate category rails on mobile Sections; type filter remains visible in the section tabs, industry rail remains above search.
- Hidden zero saved badge in the header to reduce unnecessary chrome.
