# Editorial & Rights Policy · V0.2

## What earns a place in the gallery?

- Genuine B2B website/design reference with an identifiable official source or author.
- Specific design observation that helps a web designer make a concrete visual or UX choice.
- Appropriate industry/business-model/page classification.
- Source recorded and manually checked; reviewer notes what was actually inspected.
- Honest labeling: original study, live reference, external template, design concept are different sources.

## Screenshot publication policy

Publicly reachable web pages are **not** automatically redistributable. A curator should retain verifiable permission or an applicable license and comply with its terms. Record rights holder, evidence location/reference, attribution requirements, and any use limitations. Do not paste passwords, private correspondence in full, or confidential personal data into the notes field.

If rights are uncertain, use a source link and metadata-only presentation, **not a reconstructed screenshot**. Metadata-only publication still requires checking that the listing and link are accurate and appropriate under applicable rules.

## Design quality checklist

- Does the module solve a real B2B communication problem? Which one?
- Are visual hierarchy, information density and typography legible?
- Does the page make technical specs, certifications, applications or RFQ clear where relevant?
- Is mobile adaptation plausible or observed? Mark it unobserved if not checked.
- Are observations from screenshots clearly distinguished from verified usage/conversion outcomes?
- Does the gallery preserve original creator attribution and an external source link?
- Will this case expand designer thinking, not merely repeat a prevalent template?

## Takedown handling

If rights are withdrawn, record a reason, archive immediately, remove the local image and unpublish the card. Keep a non-public audit trail for accountability. Other people may have saved/cached earlier copies outside our control.

## Publishing decisions

- `draft`: source submitted, not public.
- `in_review`: source verification and visual/editorial assessment are being decided.
- `approved`: a reviewer approved it after documented source verification.
- `published`: visible publicly; a screenshot only appears after documented permission.
- `rejected`: may be reopened for a fresh edit/review.
- `archived`: unpublished and rights revoked for local screenshot; editor may reopen a fresh application.
