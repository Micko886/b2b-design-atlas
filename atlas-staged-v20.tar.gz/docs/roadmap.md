# B2B Design Atlas · Execution Gates

| Gate | Current | Definition of done |
|---|---|---|
| V0.1 Interaction prototype | Complete | Functional website/section/pattern catalogs; search, collections, board, export; 12/48/12 original studies |
| V0.2 Editorial source workflow | Complete (pilot) | Candidate queue, manual source check, rights ledger, verified image upload, review, publish, revoke, audit tests |
| V0.3 True site/page/section anatomy | Next | Page entity, approved screenshot pairs, manually cropped/annotated sections, page-level source linkage, recheck date and section-level publication gates |
| V0.4 Public discovery/SEO | Planned | Accessible SSR detail pages and canonical URLs, sitemap, schema/structured content, analytics and content search evaluation |
| V0.5 Accounts & collections | Planned | User identity, per-user saved references, cloud collections, sharable design direction boards, role access |
| V0.6 Monetization experiment | Planned | Free/Pro access, payment method chosen by entity eligibility, subscriptions, refunds/cancellation, tax handling and price tests |
| V0.7 AI-assisted search | Conditional | Design-tag dataset quality thresholds first; semantic search verified by labeled relevance tasks |

**Evidence gate before V0.3:** gather a small number of display-authorized real sources and record license provenance. Without source rights, demonstrate metadata-only listings but do not build a large public screenshot gallery.

**Product evaluation metrics:** time to useful design reference, relevance on a curated set of search tasks, users who save references, frequency of returning designers, and observed willingness to pay. Do not treat these as proven market metrics without testing users.
