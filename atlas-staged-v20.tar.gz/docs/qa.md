# QA · V0.2

## Automated

- Existing V0.1 API compatibility checks remain.
- New candidate intake requires curator token and validates official HTTPS URL syntax.
- Third-party references cannot use bypass direct-publication endpoints.
- Draft does not appear in public gallery; approval without source-verification note fails.
- Approved metadata-only listing works and does not forge a webpage screenshot.
- Image upload requires rights holder, granted status, evidence and attribution.
- Image validation rejects SVG masquerading as PNG and payloads over 8 MiB.
- Uploaded image is normalized to WebP and can be viewed locally.
- Rights revocation unpublishes website, clears screenshot assignment and deletes local image.
- Takedown archives the public reference and prevents publishing without fresh editorial review.

Command: `python -m unittest discover -s tests -v` — **10 tests passing** at packaging time.

## Static-browser smoke test

The editorial page was rendered with Chromium and injected mock API responses, validating DOM initialization, queue listing, selection and absence of JS exceptions. This was a **mocked browser UI check**, not a full real-network browser E2E test. The actual backend flow was independently exercised by FastAPI TestClient tests.

## Manual production acceptance still needed

- Chromium/Firefox/Safari live server E2E; keyboard-only navigation; screen-reader audit; mobile cross-device testing.
- Browser CSP/cookie hardening; application security review, rate limits and permissioned user identity.
- Real rights-cleared reference publication and attribution review.
- Load tests, backups, reliability/restore procedures and webhook-based rechecks where appropriate.
