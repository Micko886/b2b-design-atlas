"""Offline draft-only discovery importer. Never approves or publishes a reference.

By default prints candidates without touching storage. Run with --apply to insert
new records into your configured database; be sure to back up DB first.
"""
from __future__ import annotations

import argparse
import csv
import sqlite3
from pathlib import Path

from app.intake import IntakeCreate


def main():
    parser = argparse.ArgumentParser(description="Add researched candidates into editorial DRAFT queue")
    parser.add_argument("--apply", action="store_true", help="Actually insert drafts (default: dry run)")
    parser.add_argument("--csv", default=str(Path(__file__).resolve().parents[1] / "docs" / "source-shortlist.csv"))
    args = parser.parse_args()
    with open(args.csv, newline="", encoding="utf-8") as file:
        candidates = list(csv.DictReader(file))
    if args.apply:
        # Only application startup (not a dry-run) initializes or mutates SQLite.
        from app.main import db
    print(f"Import candidates: {len(candidates)}; mode: {'apply' if args.apply else 'dry-run'}")
    for row in candidates:
        item = IntakeCreate(**row)
        print(f"  [{item.industry}] {item.name}: {item.source_url} => draft")
        if not args.apply:
            continue
        data = item.model_dump()
        with db() as con:
            existing = con.execute("SELECT id FROM reference_intake WHERE slug=? OR source_url=?", (item.slug, item.source_url)).fetchone()
            if existing:
                print(f"    Skipped (already exists: {existing[0]})")
                continue
            try:
                cur = con.execute("INSERT INTO reference_intake (" + ",".join(data) + ") VALUES (" + ",".join("?" for _ in data) + ")", tuple(data.values()))
                con.execute("INSERT INTO intake_audit(candidate_id,action,detail) VALUES (?,?,?)", (cur.lastrowid, "discovery_import", "Imported as unreviewed draft. No screenshot rights or manual source verification confirmed."))
            except sqlite3.IntegrityError:
                print("    Skipped (duplicate)")
    print("Complete. Nothing has been auto-reviewed or published.")


if __name__ == "__main__": main()
