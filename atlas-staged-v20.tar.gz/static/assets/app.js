/* B2B Design Atlas, original v0.1 prototype. No build step, external JS dependencies or external fonts. */
'use strict';

const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => Array.from(root.querySelectorAll(selector));
const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const icon = (name,size=18) => {
  const paths = {
    arrow:'<path d="M4 12h16m-7-7 7 7-7 7"/>',
    upRight:'<path d="M7 17 17 7M7 7h10v10"/>',
    search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5"/>',
    heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
    layers:'<path d="m12 3 9 5-9 5-9-5 9-5Zm-9 9 9 5 9-5M3 16l9 5 9-5"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    close:'<path d="M5 5 19 19M19 5 5 19"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7h.01"/>',
    grid:'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>',
    download:'<path d="M12 3v12m-4-4 4 4 4-4M4 17v4h16v-4"/>',
    copy:'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V4H5a1 1 0 0 0-1 1v11h4"/>',
    move:'<path d="M12 2v20M2 12h20m-13-7 3-3 3 3m-6 14 3 3 3-3M5 9l-3 3 3 3m14-6 3 3-3 3"/>',
    sparkle:'<path d="m12 2 2.6 7.4L22 12l-7.4 2.6L12 22l-2.6-7.4L2 12l7.4-2.6L12 2Z"/>',
    book:'<path d="M12 6C8 3 5 3 2 4v15c3-1 6-1 10 2m0-15c4-3 7-3 10-2v15c-3-1-6-1-10 2V6Z"/>',
    folder:'<path d="M3 6h7l2 2h9v12H3V6Z"/>',
    sliders:'<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="9" cy="6" r="2" fill="var(--paper)"/><circle cx="15" cy="12" r="2" fill="var(--paper)"/><circle cx="10" cy="18" r="2" fill="var(--paper)"/>',
  };
  return `<svg class="icon" style="width:${size}px;height:${size}px" viewBox="0 0 24 24" aria-hidden="true">${paths[name]||paths.grid}</svg>`;
};

const store = {
  read(key,fallback){try {const value=JSON.parse(localStorage.getItem(key));return value??fallback;}catch{return fallback}},
  write(key,value){try{localStorage.setItem(key,JSON.stringify(value))}catch{toast('Browser storage unavailable. Changes are temporary.')}}
};

const state={
  route:'home', query:'', industry:'', style:'', type:'', layout:'', sort:'curated', compact:false,
  websites:[],sections:[],patterns:[],facets:{},stats:{websites:0,sections:0,patterns:0},
  favorites:store.read('atlas:favorites',[]), board:store.read('atlas:board',[]),
  modal:null
};

const SITE_TYPES = {'websites':'website','sections':'section'};
const pathnameToRoute = () => ({'/':'home','/websites':'websites','/sections':'sections','/patterns':'patterns','/collections':'collections','/board':'board'}[location.pathname]||'home');
function setRoute(route,history=true){
  state.route=route;state.query='';state.industry='';state.style='';state.type='';state.layout='';state.sort='curated';
  const path=route==='home'?'/':`/${route}`;
  if(history)window.history.pushState({route},'',path);
  render();window.scrollTo({top:0,behavior:'instant'});
}

function toast(message){
  const region=$('#toast-region');if(!region)return;
  region.innerHTML=`<div class="toast">${esc(message)}</div>`;
  clearTimeout(toast.timer);toast.timer=setTimeout(()=>{region.innerHTML=''},2900);
}

async function init(){
  try{
    const paths=['/api/websites','/api/sections','/api/patterns','/api/facets','/api/stats'];
    const responses=await Promise.all(paths.map(path=>fetch(path).then(response=>{if(!response.ok)throw Error(`Request failed: ${path}`);return response.json()})));
    [state.websites,state.sections,state.patterns]=responses.slice(0,3).map(r=>r.items);
    state.facets=responses[3];state.stats=responses[4];
    state.route=pathnameToRoute();render();
  }catch(error){
    $('#app').innerHTML=`<div class="wrap" style="padding:100px 0"><div class="error-banner"><strong>Unable to load the reference catalog.</strong><p>${esc(error.message)}</p><p>Start the application using <code>python run.py</code> and reload this page.</p></div></div>`;
  }
}

function visualSVG(visual,uid){
  // Procedural editorial illustrations, created for the starter concept gallery.
  const gradient=`g${uid.replace(/[^a-z0-9]/g,'')}`;
  const defs=`<defs><linearGradient id="${gradient}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--mock-surface)"/><stop offset=".38" stop-color="var(--mock-accent)"/><stop offset=".62" stop-color="var(--mock-surface)"/><stop offset="1" stop-color="var(--mock-accent)"/></linearGradient></defs>`;
  let body='';
  switch(visual){
    case 'rings':
      body=`<g transform="translate(210 192) rotate(-25)"><ellipse rx="150" ry="79" fill="none" stroke="var(--mock-ink)" stroke-opacity=".17" stroke-width="1"/><ellipse rx="125" ry="55" fill="none" stroke="url(#${gradient})" stroke-width="40"/><ellipse rx="125" ry="55" fill="none" stroke="var(--mock-ink)" stroke-opacity=".32" stroke-width="1.2"/><ellipse rx="90" ry="33" fill="none" stroke="var(--mock-surface)" stroke-width="22"/><ellipse rx="72" ry="18" fill="none" stroke="var(--mock-accent)" stroke-opacity=".8" stroke-width="3"/><path d="M-156 0H157M0-115V115" stroke="var(--mock-ink)" stroke-opacity=".23" stroke-width=".8"/></g>`;
      break;
    case 'robot':
      body=`<g transform="translate(24 8)"><path d="M60 320H320" stroke="var(--mock-ink)" stroke-width="2" opacity=".35"/><rect x="185" y="288" width="90" height="30" rx="2" fill="url(#${gradient})"/><path d="M225 288 190 218 222 191 275 250 250 280Z" fill="url(#${gradient})" stroke="var(--mock-ink)" stroke-opacity=".3"/><circle cx="209" cy="215" r="27" fill="var(--mock-surface)" stroke="var(--mock-accent)" stroke-width="12"/><path d="M195 195 112 151 123 120 217 174Z" fill="url(#${gradient})"/><circle cx="121" cy="142" r="21" fill="var(--mock-surface)" stroke="var(--mock-accent)" stroke-width="9"/><path d="M120 126 155 78 185 93 140 155Z" fill="url(#${gradient})"/><path d="m155 77 16-29 34 11-13 34-28-3Z" fill="var(--mock-ink)" opacity=".75"/><path d="m179 51 23-18m-23 18 6-27" stroke="var(--mock-accent)" stroke-width="7" stroke-linecap="square"/><circle cx="209" cy="215" r="9" fill="var(--mock-ink)" opacity=".6"/><circle cx="121" cy="142" r="7" fill="var(--mock-ink)" opacity=".5"/><g stroke="var(--mock-accent)" opacity=".65"><path d="m65 73 35-15 32 12" fill="none"/><circle cx="65" cy="73" r="3" fill="currentColor"/><circle cx="132" cy="70" r="3" fill="currentColor"/></g></g>`;
      break;
    case 'layers':
      body=`<g transform="translate(0 5)"><path d="m35 220 190-140 157 81-184 145Z" fill="var(--mock-ink)" fill-opacity=".12"/><path d="m47 205 186-144 141 78-190 139Z" fill="url(#${gradient})" stroke="var(--mock-ink)" stroke-opacity=".26"/><path d="m47 178 186-144 141 78-190 139Z" fill="var(--mock-surface)" stroke="var(--mock-ink)" stroke-opacity=".25"/><path d="m47 151 186-144 141 78-190 139Z" fill="var(--mock-accent)" fill-opacity=".83" stroke="var(--mock-ink)" stroke-opacity=".2"/><path d="m60 177 170-129 125 67M60 205l170-129 125 67" stroke="var(--mock-ink)" stroke-opacity=".13" fill="none"/></g>`;
      break;
    case 'circuits':
      body=`<g transform="translate(15 8) rotate(-13 200 180)"><rect x="65" y="65" width="300" height="255" rx="8" fill="var(--mock-surface)" stroke="var(--mock-ink)" stroke-opacity=".5" stroke-width="3"/><rect x="137" y="120" width="142" height="130" fill="var(--mock-ink)" fill-opacity=".82"/><rect x="162" y="145" width="92" height="80" fill="var(--mock-accent)" fill-opacity=".26" stroke="var(--mock-accent)" stroke-width="2"/>${Array.from({length:6},(_,i)=>`<path d="M${137+i*25} 120V86H${112+i*30}M${137+i*25} 250v38h${112+i*30}M137 ${120+i*26}H94V${110+i*33}M279 ${120+i*26}h45v${110+i*33}" stroke="var(--mock-accent)" stroke-width="2.5" fill="none" opacity=".8"/><circle cx="${112+i*30}" cy="86" r="3" fill="var(--mock-accent)"/>`).join('')}<circle cx="204" cy="185" r="24" fill="none" stroke="var(--mock-surface)" stroke-width="2"/><path d="m194 185 7 7 15-16" fill="none" stroke="var(--mock-surface)" stroke-width="3"/></g>`;
      break;
    case 'arch':
      body=`<g transform="translate(26 10)"><path d="M52 344V123c0-68 55-115 124-115s125 47 125 115v221" fill="none" stroke="var(--mock-accent)" stroke-width="61"/><path d="M92 346V126c0-43 34-75 84-75s85 32 85 75v220" fill="none" stroke="var(--mock-surface)" stroke-width="14"/><path d="M51 342H309M20 333H345" stroke="var(--mock-ink)" stroke-opacity=".4" stroke-width="3"/><path d="M177 47v298M48 117h254" stroke="var(--mock-ink)" stroke-opacity=".2" stroke-dasharray="4 7"/><path d="M43 31h25m-12-12v25" stroke="var(--mock-ink)" opacity=".45"/><circle cx="177" cy="124" r="4" fill="var(--mock-ink)"/></g>`;
      break;
    case 'turbine':
      body=`<g transform="translate(208 180)"><circle r="151" fill="none" stroke="var(--mock-ink)" stroke-opacity=".18" stroke-width="2"/><circle r="110" fill="var(--mock-surface)" fill-opacity=".7" stroke="var(--mock-accent)" stroke-width="13"/>${Array.from({length:9},(_,i)=>`<path transform="rotate(${i*40})" d="M-10 -20Q-10 -60 19 -100L49 -122Q65 -35 25 3Z" fill="url(#${gradient})" stroke="var(--mock-ink)" stroke-opacity=".24" stroke-width="1"/>`).join('')}<circle r="34" fill="var(--mock-accent)"/><circle r="17" fill="var(--mock-surface)" stroke="var(--mock-ink)" stroke-opacity=".28" stroke-width="2"/><path d="M-180 0H180M0-180V180" stroke="var(--mock-ink)" stroke-opacity=".13"/></g>`;
      break;
    case 'blocks':
      body=`<g transform="translate(45 20)"><path d="m165 30 115 67-115 66-116-67Z" fill="var(--mock-surface)"/><path d="m49 96 116 67v140L49 236Z" fill="var(--mock-accent)"/><path d="m165 163 115-66v140l-115 66Z" fill="url(#${gradient})"/><path d="m165 30 115 67-115 66-116-67Z" fill="none" stroke="var(--mock-ink)" stroke-opacity=".23"/><path d="m49 96 116 67v140L49 236Zm116 67 115-66v140l-115 66Z" fill="none" stroke="var(--mock-ink)" stroke-opacity=".23"/><path d="m107 60 115 67m-99-12 115-67" stroke="var(--mock-ink)" stroke-opacity=".25"/><path d="m165 163 0 140" stroke="var(--mock-ink)" stroke-opacity=".25"/></g>`;
      break;
    case 'crates':
      body=`<g transform="translate(25 30)"><path d="m89 160 88-55 96 53-88 56Z" fill="var(--mock-surface)"/><path d="m89 160 96 54v105l-96-51Z" fill="var(--mock-accent)"/><path d="m185 214 88-56v112l-88 49Z" fill="url(#${gradient})"/><path d="m43 93 87-53 96 53-87 55Z" fill="var(--mock-surface)"/><path d="m43 93 96 55v108L43 204Z" fill="var(--mock-accent)"/><path d="m139 148 87-55v107l-87 56Z" fill="url(#${gradient})"/><path d="m43 93 96 55v108M139 148l87-55" fill="none" stroke="var(--mock-ink)" stroke-opacity=".35" stroke-width="2"/><path d="m89 160 96 54v105M185 214l88-56" fill="none" stroke="var(--mock-ink)" stroke-opacity=".25" stroke-width="2"/><path d="m92 119 21 12m-21 5 30 18m37 94 18 9" stroke="var(--mock-surface)" stroke-width="6" opacity=".8"/></g>`;
      break;
    case 'orbital':
      body=`<g transform="translate(215 177)"><circle r="115" fill="url(#${gradient})"/><circle r="115" fill="none" stroke="var(--mock-ink)" stroke-opacity=".18"/><path d="M-115 0H115M0-115V115" stroke="var(--mock-surface)" stroke-opacity=".45"/><ellipse rx="195" ry="47" transform="rotate(-25)" fill="none" stroke="var(--mock-accent)" stroke-width="12"/><ellipse rx="195" ry="47" transform="rotate(-25)" fill="none" stroke="var(--mock-surface)" stroke-opacity=".5" stroke-width="1.4"/><circle cx="164" cy="-96" r="13" fill="var(--mock-accent)"/><circle cx="-170" cy="110" r="5" fill="var(--mock-ink)"/></g>`;
      break;
    default:body=`<circle cx="220" cy="185" r="127" fill="url(#${gradient})"/><path d="M70 310 350 70" stroke="var(--mock-surface)" stroke-width="21" opacity=".6"/>`;
  }
  return `<svg viewBox="0 0 420 370" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">${defs}${body}</svg>`;
}

function renderPreview(item,kind='website'){
  const palette=/^[a-z]+$/.test(item.palette||'')?item.palette:'sand';
  const slug=esc(item.slug||'ref');
  const name=kind==='section'?(item.website_name||state.websites.find(w=>w.slug===item.website_slug)?.name||'Design study'):item.name;
  if(item.image_url){
    const source=(/^https?:\/\//i.test(item.image_url)||/^\/media\/ref-\d+-[a-f0-9]{18}\.webp$/i.test(item.image_url))?item.image_url:'';
    if(source)return `<div class="mock mock-external" data-palette="${palette}"><img class="mock-external-image" alt="Design screenshot for ${esc(name)}" src="${esc(source)}" loading="lazy"><span class="mock-source-label">${esc(name)} · ${esc(item.reference_type||item.badge||'Reference')}</span></div>`;
  }
  if(kind==='website' && item.reference_type && item.reference_type!=='Original Study'){
    return `<div class="mock mock-source-only" data-palette="${palette}"><div class="source-only-inner"><span class="mock-kicker">${esc(item.reference_type.toUpperCase())} / VERIFIED REFERENCE</span><strong>${esc(item.name)}</strong><p>${esc(item.industry)} · Original source linked</p><span class="source-placeholder-label">Image not published · metadata-only reference</span></div></div>`;
  }
  const section=kind==='section';
  const smallTitle=section?item.title:item.hero_title;
  const smallSub=section?item.summary:item.tagline;
  const kicker=section?`${item.type} / ${item.layout}`:item.hero_kicker;
  const layout=section?item.layout:'Asymmetric Split';
  const workName=name.length>22?name.slice(0,21):name;
  const className=section?'mock mock-section':'mock mock-website';
  return `<div class="${className}" data-palette="${palette}" data-layout="${esc(layout)}" data-kind="${esc(section?item.type:'Hero')}">
    <div class="mock-grid-lines"></div>
    <div class="mock-nav"><b>${esc(workName.toUpperCase())}</b><div class="mock-nav-links"><em>Expertise</em><em>Work</em><em>About</em><span>CONTACT ↗</span></div></div>
    <div class="mock-body"><div class="mock-copy"><span class="mock-kicker">${esc(kicker||'DESIGN STUDY')}</span><h4 class="mock-hero-title">${esc(smallTitle||'Ideas made tangible.')}</h4><p class="mock-hero-sub">${esc(smallSub||'Thoughtful engineering and product thinking.')}</p><span class="mock-cta">${section?'EXPLORE THE APPROACH':'EXPLORE OUR WORK'} &nbsp; ↗</span></div><div class="mock-art">${visualSVG(item.visual,slug)}</div></div>
    ${section && item.type==='Capabilities'?'<div class="mock-section-metrics"><div><b>01 / 04</b><span>ENGINEERING</span></div><div><b>02 / 04</b><span>PRODUCTION</span></div></div>':''}
    ${section && item.type==='Process'?'<div class="mock-process-steps"><span>01 / Discover</span><span>02 / Develop</span><span>03 / Deliver</span></div>':''}
    <div class="mock-index"><span>${esc(section?item.type.toUpperCase():'INDEPENDENT ENGINEERING / DESIGN STUDY')}</span><span>01 — 04</span></div>
  </div>`;
}

function refCard(item,kind){
  const website=kind==='website';const id=kind+':'+item.slug;const saved=state.favorites.includes(id);
  const title=website?item.name:item.title;
  const sub=website?`${item.industry} <span class="sep">·</span> ${item.style}`:`${item.type} <span class="sep">·</span> ${item.layout}`;
  return `<article class="reference-card">
    <div class="reference-visual" role="button" tabindex="0" data-action="detail" data-kind="${kind}" data-slug="${esc(item.slug)}" aria-label="Inspect ${esc(title)}">
      <span class="card-eye">${esc(website?item.reference_type||'Original Study':item.badge||'Original Study')}</span>
      ${renderPreview(item,kind)}
      ${website?`<span class="card-count">${state.sections.filter(s=>s.website_slug===item.slug).length} section studies</span>`:''}
    </div>
    <div class="reference-meta"><div><h3 class="reference-title">${esc(title)}</h3><div class="reference-sub">${sub}</div></div>
      <button class="favorite ${saved?'saved':''}" data-action="favorite" data-kind="${kind}" data-slug="${esc(item.slug)}" title="${saved?'Remove from favorites':'Save to collections'}" aria-label="${saved?'Remove':'Save'} ${esc(title)}">${icon('heart')}</button>
    </div>
  </article>`;
}

function filterData(kind){
  const isWebsite=kind==='websites';let items=(isWebsite?state.websites:state.sections).filter(item=>{
    const site=isWebsite?item:state.websites.find(w=>w.slug===item.website_slug);
    const q=state.query.toLowerCase().trim();
    const text=isWebsite?[item.name,item.industry,item.style,item.business_model,item.description,item.hero_title].join(' '):[item.title,item.type,item.layout,item.summary,item.website_name,item.industry,item.style].join(' ');
    return (!q||text.toLowerCase().includes(q)) && (!state.industry||site?.industry===state.industry) && (!state.style||site?.style===state.style) && (isWebsite||(!state.type||item.type===state.type)&&(!state.layout||item.layout===state.layout));
  });
  if(state.sort==='name')items.sort((a,b)=>(a.name||a.title).localeCompare(b.name||b.title));
  if(state.sort==='newest')items.sort((a,b)=>b.id-a.id);
  if(state.sort==='curated')items.sort((a,b)=>b.featured-a.featured||a.id-b.id);
  return items;
}

function selectControl(name,placeholder,options){
  return `<div class="select-wrap"><select aria-label="${esc(placeholder)}" data-filter="${esc(name)}"><option value="">${esc(placeholder)}</option>${(options||[]).map(v=>`<option value="${esc(v)}" ${state[name]===v?'selected':''}>${esc(v)}</option>`).join('')}</select></div>`;
}

function renderCatalogTools(kind){
  return `<div class="filters">
    <label class="search-field">${icon('search')}<input id="search-ref" type="search" value="${esc(state.query)}" placeholder="Search industry, layout, website, purpose..." autocomplete="off" aria-label="Search references"/></label>
    ${selectControl('industry','All industries',state.facets.industries)}
    ${selectControl('style','All styles',state.facets.styles)}
    ${kind==='sections'?selectControl('type','All sections',state.facets.types):selectControl('sort','Curated first',["name","newest"])}
    ${kind==='sections'?selectControl('layout','All layouts',state.facets.layouts):''}
    <button class="filter-reset" data-action="reset-filter">Reset filters</button>
  </div>
  <div class="catalog-toolbar"><span id="catalog-count"></span><div class="view-switch"><button class="${state.compact?'':'is-active'}" data-action="grid-mode" data-mode="large" aria-label="Large gallery">${icon('grid',15)} Gallery</button><button class="${state.compact?'is-active':''}" data-action="grid-mode" data-mode="compact" aria-label="Compact gallery">Compact</button></div></div>`;
}

function renderCatalogResult(){
  const kind=state.route;if(!SITE_TYPES[kind])return;
  const items=filterData(kind);const el=$('#catalog-results');if(!el)return;
  $('#catalog-count').innerHTML=`Showing <strong>${items.length}</strong> curated ${kind==='websites'?'website studies':'section studies'}`;
  if(!items.length){el.innerHTML=`<div class="empty-state"><h3>No references found.</h3><p>Try another industry, broaden your search, or clear a filter.</p><button class="button button-secondary" data-action="reset-filter">Clear filters ${icon('arrow')}</button></div>`;return;}
  el.innerHTML=`<div class="gallery-grid ${state.compact?'compact':''}">${items.map(item=>refCard(item,SITE_TYPES[kind])).join('')}</div>`;
}

function renderHome(){
  const first=state.websites[0],featured=state.websites.filter(w=>w.featured).slice(0,3),sections=state.sections.filter(s=>s.featured).slice(0,3);
  return `<section class="home-hero"><div class="wrap hero-grid"><div class="hero-intro"><div class="eyebrow with-line">THE DESIGN REFERENCE FOR B2B</div><h1 class="hero-title">Build beyond<br><i>the expected.</i></h1><p class="hero-description">Discover considered B2B website design. Explore sections, study the thinking behind each layout, and turn better references into better work.</p><div class="hero-ctas"><a class="button button-primary" data-nav="websites" href="/websites">Explore websites ${icon('arrow')}</a><a class="button button-secondary" data-nav="sections" href="/sections">Browse sections ${icon('upRight')}</a></div><div class="hero-micro"><span><b>${state.stats.websites}</b> website references</span><span><b>${state.stats.sections}</b> section concepts</span><span><b>${state.stats.patterns}</b> layout patterns</span></div></div><div class="hero-feature"><div class="hero-art-back"></div><div class="hero-art-wrap">${renderPreview(first)}</div><div class="hero-doodle"><span class="tiny">FIELD NOTE / 001</span><strong>Less template.<br>More intention.</strong></div></div></div></section>
  <div class="wrap home-index"><div class="index-left"><span>01 / CURATED INSPIRATION</span><span>02 / DESIGN ANATOMY</span><span>03 / PROJECT BOARDS</span></div><a class="index-link" data-nav="patterns" href="/patterns">Study layout patterns ${icon('upRight',14)}</a></div>
  <section class="section-spacing" style="padding-top:32px"><div class="wrap"><div class="section-heading"><div><span class="eyebrow">EDITOR'S SELECTION / 01</span><h2>Websites worth studying.</h2></div><a class="text-link" data-nav="websites" href="/websites">View all website studies ${icon('upRight',15)}</a></div><div class="concept-notice">${icon('info',15)} <span><strong>Starter references:</strong> original studies are fictional design concepts; entries labeled Live Website have separate verified source records and may be metadata-only.</span></div><div class="home-card-grid">${featured.map(w=>refCard(w,'website')).join('')}</div></div></section>
  <section class="home-dark-band"><div class="wrap dark-inner"><div><span class="eyebrow" style="color:#b4c9b7">MORE THAN PRETTY PAGES</span><h2>The eye is trained.<br><i>Not inherited.</i></h2><p>Good references show what is possible. Thoughtful analysis helps you see why it works — the grid, hierarchy, composition and B2B context.</p><a class="button" style="background:#dce8d8;color:#25382b;margin-top:13px" href="/patterns" data-nav="patterns">Explore design patterns ${icon('arrow')}</a></div><div class="dark-feature-list"><div class="dark-feature"><span class="figure">01.</span><div><strong>Discover</strong><span>Find visual directions matched to the job.</span></div></div><div class="dark-feature"><span class="figure">02.</span><div><strong>Understand</strong><span>Learn the decisions behind the design.</span></div></div><div class="dark-feature"><span class="figure">03.</span><div><strong>Compose</strong><span>Collect references into a clear direction.</span></div></div></div></div></section>
  <section class="section-spacing"><div class="wrap"><div class="section-heading"><div><span class="eyebrow">SECTION LIBRARY / 02</span><h2>One purpose. Many forms.</h2></div><div><p>Explore how different layouts can communicate the same B2B idea — without repeating the same component formula.</p><a class="text-link" data-nav="sections" href="/sections">Explore all sections ${icon('upRight',15)}</a></div></div><div class="home-card-grid">${sections.map(s=>refCard(s,'section')).join('')}</div></div></section>
  <section class="home-last-band"><div class="wrap home-last-inner"><div><span class="eyebrow">YOUR NEXT DESIGN DIRECTION</span><h2>Turn inspiration into<br><i>a considered plan.</i></h2></div><a class="button button-primary" href="/board" data-nav="board">Open your design board ${icon('upRight')}</a></div></section>`;
}

function renderExplore(kind){
  const isWebsite=kind==='websites';
  return `<div class="wrap"><section class="explore-top"><div class="explore-topline"><span class="eyebrow">DESIGN LIBRARY / ${isWebsite?'WEBSITES':'SECTIONS'}</span><span style="color:#8c978c;font-size:11px">CURATED ORIGINAL STUDIES</span></div><h1 class="explore-title">${isWebsite?'Explore websites.':'Explore sections.'}</h1><p class="explore-description">${isWebsite?'Discover B2B website design directions across manufacturing, engineering, technology and supply chain. Study the complete visual language, not just a pretty homepage.':'Find a better visual approach for the exact part of a B2B website you are designing. Compare layout patterns, content fit and editorial decisions.'}</p></section><section class="catalog-area">${renderCatalogTools(kind)}<div id="catalog-results"></div></section></div>`;
}

function renderPatterns(){
  const q=state.query.toLowerCase().trim();const items=state.patterns.filter(p=>!q||[p.name,p.description,p.family,p.guidance].join(' ').toLowerCase().includes(q));
  return `<div class="wrap"><section class="explore-top"><span class="eyebrow">DESIGN INTELLIGENCE / 03</span><h1 class="explore-title">The language of layout.</h1><p class="explore-description">Learn the visual principles behind memorable B2B websites. Each pattern includes where it works, what it communicates and when to avoid it.</p></section><section class="catalog-area"><div class="filters"><label class="search-field">${icon('search')}<input id="pattern-search" type="search" placeholder="Search layout concepts..." aria-label="Search layout patterns" value="${esc(state.query)}"></label><span style="font-size:11px;color:#78847a">${items.length} design patterns</span></div><div id="pattern-results" class="patterns-grid">${items.map(patternCard).join('')}</div></section></div>`;
}
function patternCard(p){
  return `<button class="pattern-card" data-action="detail" data-kind="pattern" data-slug="${esc(p.slug)}"><div class="pattern-card-head"><span class="pattern-family">${esc(p.family)}</span>${icon('upRight',22)}</div><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p><div class="pattern-card-footer"><span>${esc(p.structure)}</span><span>${p.examples} examples ↗</span></div></button>`;
}

function resolveRef(key){const [kind,...slug]=key.split(':');return kind==='website'?state.websites.find(x=>x.slug===slug.join(':')):state.sections.find(x=>x.slug===slug.join(':'));}
function renderCollections(){
  const data=state.favorites.map(key=>({kind:key.split(':')[0],item:resolveRef(key)})).filter(row=>row.item);
  return `<div class="wrap utility-page"><div class="utility-intro"><div><span class="eyebrow">YOUR REFERENCE SHELF</span><h1>Collections.</h1><p>Save what catches your eye, revisit design choices and gather useful references as your project takes shape. Saved in this browser for the prototype.</p></div><a href="/board" data-nav="board" class="button button-primary">Open design board ${icon('arrow')}</a></div><div class="board-overview"><span>${icon('heart',15)} &nbsp; <strong>${data.length} saved references</strong> in this browser</span><span>Favorites work without an account · no cloud sync yet</span></div>${data.length?`<div class="gallery-grid">${data.map(row=>refCard(row.item,row.kind)).join('')}</div>`:`<div class="collection-empty">${icon('heart',38)}<h3>Good references belong together.</h3><p>Browse websites or sections, then tap the heart on anything worth keeping. Your saved work will appear here.</p><a href="/sections" data-nav="sections" class="button button-primary">Explore the library ${icon('arrow')}</a></div>`}</div>`;
}

function boardItem(s,index){
  return `<div class="board-item" draggable="true" data-board-slug="${esc(s.slug)}"><div class="board-num">${String(index+1).padStart(2,'0')}</div><div style="width:120px;max-width:100%">${renderPreview(s,'section')}</div><div><div class="board-title">${esc(s.title)}</div><div class="board-sub">${esc(s.type)} / ${esc(s.layout)}<br>${esc(s.website_name||'Original study')}</div></div><button class="board-remove" data-action="remove-board" data-slug="${esc(s.slug)}" title="Remove section" aria-label="Remove ${esc(s.title)}">×</button></div>`;
}
function renderBoard(){
  const items=state.board.map(slug=>state.sections.find(s=>s.slug===slug)).filter(Boolean);
  const savedSections=state.favorites.filter(x=>x.startsWith('section:')).map(resolveRef).filter(s=>s&&!state.board.includes(s.slug));
  return `<div class="wrap utility-page"><div class="utility-intro"><div><span class="eyebrow">WORKSPACE / YOUR PROJECT</span><h1>Design board.</h1><p>Build a visual direction, not a collage. Add section references, reorder them, and export a concise creative brief.</p></div><a href="/sections" data-nav="sections" class="button button-secondary">Find more sections ${icon('upRight')}</a></div>
    <div class="board-overview"><span><b>${items.length}</b> section${items.length!==1?'s':''} in your board · Drag to reorder on desktop</span><span>Stored locally in this browser</span></div>
    <div class="board-layout"><div class="board-canvas"><h2>B2B website / Homepage direction</h2><p>YOUR WORKING COMPOSITION</p>${items.length?items.map(boardItem).join(''):`<div class="board-empty"><h3>Start with a single idea.</h3><p>Explore the section library, open a reference, and choose “Add to board”. Build the sequence from there.</p><a class="button button-primary" href="/sections" data-nav="sections">Browse sections ${icon('arrow')}</a></div>`}</div><aside class="board-aside"><span class="eyebrow">CREATIVE DIRECTION</span><h3>Your reference brief</h3><p>The board documents what each section is trying to accomplish, which layout is being considered, and the original reference context. It is not a website editor.</p><div class="board-actions"><button class="button button-primary" data-action="download-brief" ${items.length?'':'disabled'}>${icon('download')} Download Markdown brief</button><button class="button button-secondary" data-action="copy-brief" ${items.length?'':'disabled'}>${icon('copy')} Copy creative brief</button></div>${savedSections.length?`<div class="board-tip"><h4>Add from saved sections</h4>${savedSections.slice(0,4).map(s=>`<button class="button button-secondary" style="margin:5px 0 0;width:100%;white-space:normal;text-align:left" data-action="add-board" data-slug="${esc(s.slug)}">${icon('plus',13)} ${esc(s.title)}</button>`).join('')}</div>`:''}<div class="board-tip"><h4>A good rule of thumb</h4><p>Combine expressive and quiet sections. Give dense technical information space to breathe. Use each reference for its logic, not for direct imitation.</p></div></aside></div></div>`;
}

function render(){
  $$('.site-nav a').forEach(a=>a.classList.toggle('active',a.dataset.nav===state.route));
  $('#app').innerHTML=state.route==='home'?renderHome():state.route==='patterns'?renderPatterns():state.route==='collections'?renderCollections():state.route==='board'?renderBoard():renderExplore(state.route);
  if(SITE_TYPES[state.route])renderCatalogResult();
  document.title=`${state.route==='home'?'Better references. Better B2B websites.':state.route.charAt(0).toUpperCase()+state.route.slice(1)} — B2B Design Atlas`;
}

function toggleFavorite(kind,slug){
  const key=`${kind}:${slug}`;const i=state.favorites.indexOf(key);
  if(i>=0)state.favorites.splice(i,1);else state.favorites.push(key);
  store.write('atlas:favorites',state.favorites);toast(i>=0?'Removed from your collection':'Saved to your collection');
  if(state.route==='collections')render();else{
    $$(`[data-action="favorite"][data-kind="${kind}"][data-slug="${slug}"]`).forEach(btn=>{
      btn.classList.toggle('saved',i<0);
      btn.setAttribute('aria-label',i<0?'Remove from favorites':'Save to favorites');
      btn.title=i<0?'Remove from favorites':'Save to collections';
    });
  }
  if(state.modal)renderModal();
}
function addToBoard(slug){
  if(!state.sections.some(s=>s.slug===slug)){toast('Section not found');return;}
  if(state.board.includes(slug)){toast('This section is already on your board');return;}
  state.board.push(slug);store.write('atlas:board',state.board);toast('Added to design board');
  if(state.route==='board')render();if(state.modal)renderModal();
}

function briefText(){
  const items=state.board.map(slug=>state.sections.find(s=>s.slug===slug)).filter(Boolean);
  const result=['# B2B Website — Design Direction Brief','','Generated from B2B Design Atlas original study references.','','## Proposed section sequence',''];
  items.forEach((s,index)=>{
    result.push(`### ${String(index+1).padStart(2,'0')}. ${s.type} — ${s.title}`,'',`- Reference: ${s.website_name||'Original study'}`,`- Layout approach: ${s.layout}`,`- Communicates: ${s.summary}`,`- Design principle: ${s.principle}`,`- Watch out for: ${s.pitfall}`,`- Content fit: ${s.content_fit}`,'');
  });
  result.push('## Direction notes','','- Use references to learn visual principles, not to copy third-party design or code.','- Validate hierarchy, accessibility, content accuracy and mobile responsiveness.','- This starter library uses fictional original concepts, not verified live sites.','');
  return result.join('\n');
}
function downloadBrief(){
  const blob=new Blob([briefText()],{type:'text/markdown;charset=utf-8'});
  const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='b2b-design-direction.md';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),4000);toast('Markdown brief downloaded');
}

function modalFor(kind,slug){
  const source=kind==='website'?state.websites:kind==='section'?state.sections:state.patterns;
  return source.find(x=>x.slug===slug)||null;
}
function openModal(kind,slug){
  if(!modalFor(kind,slug)){toast('Reference not found');return;}
  state.modal={kind,slug};renderModal();
  document.body.classList.add('has-modal');
  $('.detail-top button')?.focus();
}
function closeModal(){state.modal=null;$('#modal-root').innerHTML='';document.body.classList.remove('has-modal')}
function renderModal(){
  if(!state.modal)return;const {kind,slug}=state.modal;const item=modalFor(kind,slug);if(!item){closeModal();return;}
  let body='';
  if(kind==='pattern'){
    const similar=state.sections.filter(s=>s.layout===item.name).slice(0,7);
    body=`<div class="detail-header"><div><span class="eyebrow">LAYOUT PATTERN / ${esc(item.family)}</span><h2>${esc(item.name)}</h2><p>${esc(item.description)}</p></div><div class="detail-head-actions"><button class="button button-secondary" data-action="show-pattern-examples" data-layout="${esc(item.name)}">View examples ${icon('arrow')}</button></div></div><div class="detail-grid"><div class="detail-section"><h3>Design anatomy</h3><p>${esc(item.description)}</p><div class="insight-list"><div class="insight"><b>When it works</b><p>${esc(item.guidance)}</p></div><div class="insight"><b>When to avoid it</b><p>${esc(item.avoid)}</p></div></div></div><aside class="detail-facts"><dl><dt>Family</dt><dd>${esc(item.family)}</dd><dt>Grid logic</dt><dd>${esc(item.structure)}</dd><dt>Examples</dt><dd>${similar.length} current section studies</dd></dl></aside></div>${similar.length?`<div class="related-strip"><h3>Study this pattern in context</h3><div class="related-items">${similar.map(s=>`<button data-action="detail" data-kind="section" data-slug="${esc(s.slug)}">${esc(s.website_name)} / ${esc(s.type)} ↗</button>`).join('')}</div></div>`:''}`;
  }else{
    const website=kind==='website';
    const name=website?item.name:item.title;
    const saved=state.favorites.includes(`${kind}:${slug}`);
    const boardHas=state.board.includes(slug);
    const context=website?item.business_model:`${item.type} · ${item.layout}`;
    const related=website?state.sections.filter(s=>s.website_slug===item.slug):state.sections.filter(s=>s.layout===item.layout&&s.slug!==item.slug).slice(0,6);
    const description=website?item.description:item.summary;
    body=`<div class="detail-header"><div><span class="eyebrow">${website?'WEBSITE REFERENCE':'SECTION ANATOMY'} / ${esc(item.industry||'B2B')}</span><h2>${esc(name)}</h2><p>${esc(description)}</p></div><div class="detail-head-actions"><button class="button button-secondary" data-action="favorite" data-kind="${kind}" data-slug="${esc(slug)}">${icon('heart')} ${saved?'Saved':'Save'}</button>${website?'':`<button class="button button-primary" data-action="add-board" data-slug="${esc(slug)}" ${boardHas?'disabled':''}>${icon(boardHas?'check':'plus')} ${boardHas?'On board':'Add to board'}</button>`}</div></div>
      <div class="detail-visual">${renderPreview(item,kind)}</div><div class="detail-grid"><div class="detail-section"><h3>${website?'The design direction':'Why this layout works'}</h3><p>${esc(website?item.design_note:item.principle)}</p><div class="insight-list"><div class="insight"><b>Purpose & context</b><p>${esc(website?item.tagline:item.content_fit)}</p></div><div class="insight"><b>Design intent</b><p>${esc(website?'A coordinated visual identity across the website. Study the hierarchy, type rhythm and visual restraint.':item.summary)}</p></div><div class="insight"><b>Watch out for</b><p>${esc(website?'A cohesive visual system still needs usable product navigation, credible proof and accessible mobile layouts.':item.pitfall)}</p></div></div></div><aside class="detail-facts"><dl><dt>Type</dt><dd>${esc(website?'Website Study':item.type)}</dd><dt>Industry</dt><dd>${esc(item.industry)}</dd><dt>Style</dt><dd>${esc(item.style)}</dd><dt>${website?'Business model':'Layout'}</dt><dd>${esc(website?context:item.layout)}</dd><dt>Source type</dt><dd>${esc(website?item.reference_type:item.badge)}</dd><dt>Origin</dt><dd>${website?(item.reference_type==='Original Study'?'Self-authored study':'External source · '+esc(item.name)):esc(item.website_name)}</dd></dl>${item.source_url?`<a class="button button-secondary" style="margin-top:20px" href="${esc(item.source_url)}" target="_blank" rel="noopener noreferrer">Visit original source ${icon('upRight')}</a>`:''}</aside></div>
      ${related.length?`<div class="related-strip"><h3>${website?'Inside this website direction':'Same approach, new context'}</h3><div class="related-items">${related.map(s=>`<button data-action="detail" data-kind="section" data-slug="${esc(s.slug)}">${esc(s.type)} / ${esc(s.layout)} ↗</button>`).join('')}</div></div>`:''}
      <p class="source-disclaimer">${esc(website?item.reference_type:item.badge)} · ${website&&item.reference_type!=='Original Study'?'Third-party reference; attribution and source details are held in the editorial record. No UX performance claims are made.':'Original fictional study for demonstration. No performance or conversion claims are implied.'}</p>`;
  }
  $('#modal-root').innerHTML=`<div class="modal-overlay" data-action="overlay"><div class="detail-panel" role="dialog" aria-modal="true" aria-label="Design reference details"><div class="detail-top"><span class="detail-breadcrumb">B2B ATLAS / ${esc(kind.toUpperCase())} / REFERENCE</span><button data-action="close-modal" aria-label="Close details">×</button></div><div class="detail-content">${body}</div></div></div>`;
}

function showExamples(layout){closeModal();setRoute('sections');state.layout=layout;render();}

/* One delegated handler keeps cards, dynamically-rendered collections and modal controls consistent. */
document.addEventListener('click',event=>{
  const nav=event.target.closest('[data-nav]');
  if(nav){event.preventDefault();setRoute(nav.dataset.nav);$('.site-nav')?.classList.remove('show');return;}
  const action=event.target.closest('[data-action]');if(!action)return;
  const {action:doAction,kind,slug}=action.dataset;
  if(doAction==='detail')openModal(kind,slug);
  if(doAction==='favorite')toggleFavorite(kind,slug);
  if(doAction==='add-board')addToBoard(slug);
  if(doAction==='remove-board'){state.board=state.board.filter(x=>x!==slug);store.write('atlas:board',state.board);render();toast('Removed from design board')}
  if(doAction==='close-modal')closeModal();
  if(doAction==='overlay'&&event.target===action)closeModal();
  if(doAction==='reset-filter'){state.query='';state.industry='';state.style='';state.type='';state.layout='';state.sort='curated';render()}
  if(doAction==='grid-mode'){state.compact=action.dataset.mode==='compact';render()}
  if(doAction==='open-search'){setRoute('websites');setTimeout(()=>$('#search-ref')?.focus(),30)}
  if(doAction==='mobile-menu'){const nav=$('.site-nav');const expanded=nav.classList.toggle('show');action.setAttribute('aria-expanded',String(expanded))}
  if(doAction==='download-brief')downloadBrief();
  if(doAction==='copy-brief'){navigator.clipboard?.writeText(briefText()).then(()=>toast('Brief copied to clipboard')).catch(()=>toast('Clipboard access unavailable. Download the brief instead.'))}
  if(doAction==='show-pattern-examples')showExamples(action.dataset.layout);
});

document.addEventListener('input',event=>{
  if(event.target.id==='search-ref'){state.query=event.target.value;renderCatalogResult()}
  if(event.target.id==='pattern-search'){
    state.query=event.target.value;const q=state.query.toLowerCase();
    $('#pattern-results').innerHTML=state.patterns.filter(p=>[p.name,p.description,p.family,p.guidance].join(' ').toLowerCase().includes(q)).map(patternCard).join('')||'<div class="empty-state"><p>No matching patterns</p></div>';
  }
});
document.addEventListener('change',event=>{
  const key=event.target.dataset.filter;
  if(key){state[key]=event.target.value;renderCatalogResult()}
});
document.addEventListener('keydown',event=>{
  if(event.key==='Escape'&&state.modal){closeModal();return;}
  const clickable=event.target.closest('[role="button"][data-action="detail"]');
  if(clickable&&(event.key==='Enter'||event.key===' ')){event.preventDefault();openModal(clickable.dataset.kind,clickable.dataset.slug)}
});
window.addEventListener('popstate',()=>{state.route=pathnameToRoute();state.modal&&closeModal();render()});
let dragSlug=null;
document.addEventListener('dragstart',event=>{const card=event.target.closest('.board-item');if(card){dragSlug=card.dataset.boardSlug;card.classList.add('dragging');event.dataTransfer.effectAllowed='move'}});
document.addEventListener('dragend',event=>{event.target.closest('.board-item')?.classList.remove('dragging');dragSlug=null});
document.addEventListener('dragover',event=>{if(dragSlug&&event.target.closest('.board-item'))event.preventDefault()});
document.addEventListener('drop',event=>{
  if(!dragSlug)return;const target=event.target.closest('.board-item');if(!target)return;event.preventDefault();const targetSlug=target.dataset.boardSlug;
  if(dragSlug!==targetSlug){state.board=state.board.filter(x=>x!==dragSlug);state.board.splice(state.board.indexOf(targetSlug),0,dragSlug);store.write('atlas:board',state.board);render()}
  dragSlug=null;
});
init();
