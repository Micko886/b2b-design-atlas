/* Standalone editorial UI. The curator token never enters localStorage, a cookie or the URL. */
const $=selector=>document.querySelector(selector);
const escapeText=value=>String(value??'').replace(/[&<>"']/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const state={token:'',items:[],current:null,record:null};
const show=(message,error=false)=>{const box=$('#notice');box.textContent=message;box.classList.toggle('error',error);box.style.display='block';clearTimeout(show.timeout);show.timeout=setTimeout(()=>box.style.display='none',7000)};
async function request(path,options={}){
 const headers={'X-Admin-Token':state.token,...(options.headers||{})};
 if(options.body && !(options.body instanceof FormData)) headers['Content-Type']='application/json';
 const result=await fetch('/api/admin/intake'+path,{...options,headers,cache:'no-store'});
 let value={};try{value=await result.json()}catch{}
 if(!result.ok){const detail=value.detail;throw Error(typeof detail==='string'?detail:JSON.stringify(detail||`Request failed (${result.status})`))}
 return value;
}
async function refresh(preferred){
 const params=new URLSearchParams();const status=$('#queue-status').value;const q=$('#queue-search').value;
 if(status)params.set('status',status);if(q.trim())params.set('q',q.trim());
 const data=await request('?'+params);state.items=data.items;
 const summary=data.summary;
 const states=['draft','in_review','approved','published','archived'];
 $('#stats').innerHTML=states.map(s=>`<div class="metric"><strong>${summary[s]||0}</strong><span>${s.replace('_',' ')}</span></div>`).join('');
 $('#queue').innerHTML=state.items.length?state.items.map(item=>`<button class="candidate ${state.current===item.id?'active':''}" data-id="${item.id}"><span><strong>${escapeText(item.name)}</strong><small>${escapeText(item.source_url)}</small></span><span class="badge ${item.status}">${escapeText(item.status.replace('_',' '))}</span></button>`).join(''):'<div class="empty">No references match these filters.</div>';
 if(preferred) await openRecord(preferred);
}
const fields=['name','source_url','industry','business_model','style','hero_title','description','design_note','rights_status','rights_holder','rights_evidence','attribution','submission_note'];
async function openRecord(id){
 const record=await request('/'+id);state.current=record.id;state.record=record;
 $('#editor-empty').style.display='none';$('#editor').style.display='block';
 $('#record-status').textContent=record.status.replace('_',' ');$('#record-status').className='badge '+record.status;
 for(const f of fields) $('#edit-form').querySelector(`[name="${f}"]`).value=record[f]||'';
 $('#verified-display').textContent=record.source_checked_at?`Manually checked: ${record.source_checked_at} · ${record.source_check_note}`:'Not manually verified. Verify the official website before approval.';
 $('#shot-preview').hidden=!record.screenshot_path;if(record.screenshot_path)$('#shot-preview').src=record.screenshot_path;
 else $('#shot-preview').removeAttribute('src');
 $('#audit').innerHTML=record.audit.length?record.audit.map(a=>`<li><b>${escapeText(a.action)}</b><small>${escapeText(a.created_at)}</small><div>${escapeText(a.detail)}</div></li>`).join(''):'<li>No audit history</li>';
 const disabled={
  'verify':!['draft','in_review'].includes(record.status),
  'submit':record.status!=='draft',
  'approve':record.status!=='in_review',
  'reject':!['draft','in_review','approved'].includes(record.status),
  'reopen':!['rejected','approved','archived'].includes(record.status),
  'shot-upload':!['draft','in_review'].includes(record.status)||record.rights_status!=='granted',
  'publish':record.status!=='approved',
  'takedown':record.status==='archived',
  'save-edit':['archived','rejected'].includes(record.status)
 };
 for(const [key,value] of Object.entries(disabled))$('#'+key).disabled=value;
 document.querySelectorAll('.candidate').forEach(el=>el.classList.toggle('active',Number(el.dataset.id)===record.id));
}
async function act(fn){try{if(!state.current)throw Error('Select a reference');await fn();await refresh(state.current);show('Record updated successfully.')}catch(e){show(e.message,true)}}
$('#connect').addEventListener('click',async()=>{state.token=$('#secret').value.trim();if(!state.token){show('Enter your admin token',true);return}try{await refresh();show('Editorial queue connected.')}catch(e){show(e.message,true)}});
$('#secret').addEventListener('keydown',event=>{if(event.key==='Enter')$('#connect').click()});
$('#new-toggle').addEventListener('click',()=>{const form=$('#new-form');form.style.display=form.style.display==='block'?'none':'block'});
$('#create-form').addEventListener('submit',async event=>{event.preventDefault();try{const payload=Object.fromEntries(new FormData(event.target));const result=await request('',{method:'POST',body:JSON.stringify(payload)});event.target.reset();$('#new-form').style.display='none';$('#queue-status').value='';$('#queue-search').value='';await refresh(result.id);show('Candidate created in draft.')}catch(e){show(e.message,true)}});
$('#queue').addEventListener('click',event=>{const target=event.target.closest('[data-id]');if(target)openRecord(Number(target.dataset.id)).catch(e=>show(e.message,true))});
let filterTimer;$('#queue-search').addEventListener('input',()=>{clearTimeout(filterTimer);filterTimer=setTimeout(()=>refresh().catch(e=>show(e.message,true)),250)});
$('#queue-status').addEventListener('change',()=>refresh().catch(e=>show(e.message,true)));
$('#edit-form').addEventListener('submit',event=>{event.preventDefault();act(async()=>{const payload={};for(const field of fields){const value=$('#edit-form').querySelector(`[name="${field}"]`).value;if(value!==(state.record[field]||''))payload[field]=value}if(!Object.keys(payload).length)throw Error('No changes to save');await request('/'+state.current,{method:'PATCH',body:JSON.stringify(payload)})})});
$('#verify').addEventListener('click',()=>act(()=>request('/'+state.current+'/verify',{method:'POST',body:JSON.stringify({note:$('#check-note').value,reviewer:$('#reviewer').value})})));
$('#submit').addEventListener('click',()=>act(()=>request('/'+state.current+'/submit',{method:'POST'})));
for(const decision of ['approve','reject','reopen'])$('#'+decision).addEventListener('click',()=>act(()=>request('/'+state.current+'/review',{method:'POST',body:JSON.stringify({decision,note:$('#review-note').value,reviewer:$('#reviewer').value})})));
$('#shot-upload').addEventListener('click',()=>act(async()=>{const file=$('#shot-input').files[0];if(!file)throw Error('Choose an image file first');const form=new FormData();form.append('file',file);await request('/'+state.current+'/screenshot',{method:'POST',body:form});$('#shot-input').value=''}));
$('#publish').addEventListener('click',()=>act(()=>request('/'+state.current+'/publish',{method:'POST'})));
$('#takedown').addEventListener('click',()=>act(async()=>{if(!confirm('Remove this reference from the public gallery and archive it?'))return;await request('/'+state.current+'/takedown',{method:'POST',body:JSON.stringify({reason:$('#takedown-reason').value,reviewer:$('#reviewer').value})})}));
