"""Curated visual regions from real B2B website browser captures.

No AI-generated/reconstructed screenshots. The image crop is a literal pixel
region from the browser screenshot. Review/attribution stays with the source.
"""
import json
from pathlib import Path
from PIL import Image
ROOT = Path(__file__).resolve().parent
SOURCE = json.loads((ROOT/'app/source_index.json').read_text(encoding='utf-8'))
PAGES={p['id']:p for p in SOURCE['notes']}
# (slug, parent capture, category, title, editorial observation, crop y0, crop y1)
REGIONS=[
('fictiv-capability-hero','fictiv-0','Capabilities','Capability-first hero','Technical capabilities are named before the quote action. The visual turns a complicated service set into a legible entry point.',140,702),
('fictiv-process-intro','fictiv-1','Process','Process explainer','One simple proposition, a staged delivery illustration, and a clear next step.',130,634),
('fictiv-process-stages','fictiv-1','Process','Four-stage production flow','The next region reveals a stepwise journey. This crop includes only the portion visible in the original capture.',633,900),
('protolabs-service-intro','protolabs-3','Hero','Manufacturing services hero','Broad service promise with real manufacturing parts and a technical qualification cue.',133,478),
('protolabs-service-grid','protolabs-3','Products','Manufacturing process grid','Four parallel service choices let engineers orient quickly before reading details.',478,900),
('formlabs-applications-hero','formlabs-5','Hero','Application-led hero','The introduction pairs a use-case description with motion/product imagery and a sample request.',57,552),
('formlabs-application-story','formlabs-5','Applications','Rapid prototyping feature','A technical use case is given its own editorial image-and-text composition.',553,900),
('gensler-project-gallery','gensler-15','Projects','Project portfolio grid','Large photographs and minimal labels let completed client work lead the story.',95,676),
('kuka-robot-hero','kuka-10','Products','Industrial robot range','A product-family entry point built around scale and visual product continuity.',115,694),
('sandvik-product-launch','sandvik-coromant-7','Products','Cutting tools launch','Product photography has the stage while the text remains disciplined and searchable.',182,890),
('xometry-rfq-first','xometry-24','RFQ','Quote-first service hero','A conversion panel sits next to detailed technical service language without hiding specifications.',140,656),
('xometry-capabilities','xometry-23','Capabilities','Capabilities navigator','An industrial service catalog is organized around what the buyer needs to make.',105,710),
('arburg-product-family','arburg-19','Products','Machine range introduction','A complex equipment category is introduced through a focused industrial image and supporting details.',118,735),
('igus-product-family','igus-21','Products','Motion systems overview','The introductory section makes a diverse set of parts feel like one clear family.',135,720),
('hexagon-capability','hexagon-18','Capabilities','Engineering capabilities','Technical system strengths are framed with a deliberate content hierarchy.',135,735),
('formlabs-industry-usecases','formlabs-6','Applications','Industrial use-case story','An application-oriented path bridges product specifications and buyer context.',105,770),
]
def metadata():
  result=[]
  for slug,pid,category,title,note,y0,y1 in REGIONS:
    p=PAGES[pid]
    result.append(dict(id=slug,site_id=p['site_id'],page_id=pid,category=category,
         type=category,title=title,lesson=note,summary=p.get('summary',''),
         url=p['url'],source_capture=f'/screenshots/notes/{pid}.webp',
         image_file=f'{slug}.webp',crop_px=[0,y0,1440,y1],
         reference_type='Real website — browser crop'))
  return result

def make_crops():
  target=ROOT/'screenshots/modules';target.mkdir(parents=True,exist_ok=True)
  passed=[];skipped=[]
  for item in metadata():
    source=ROOT/'screenshots/notes'/f"{item['page_id']}.webp"
    if not source.is_file():skipped.append(item['id']);continue
    im=Image.open(source).convert('RGB')
    # Only crop actual screenshot pixels. No upscaling or generated artwork.
    x0,y0,x1,y1=item['crop_px']
    crop=im.crop((min(x0,im.width),min(y0,im.height),min(x1,im.width),min(y1,im.height)))
    if crop.width<800 or crop.height<180:skipped.append(item['id']);continue
    crop.save(target/item['image_file'],format='WEBP',quality=87,method=5)
    passed.append(item['id'])
  print('ACTUAL SCREENSHOT CROPS',len(passed),'/',len(REGIONS),'SKIPPED',skipped)
  if skipped: raise SystemExit('Missing or invalid real source screenshots: '+','.join(skipped))

if __name__=='__main__':make_crops()
