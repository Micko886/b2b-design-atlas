import json
import unittest
from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app

class SourceIndexTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client=TestClient(app)
        cls.index=json.loads((Path(__file__).resolve().parents[1]/'app/source_index.json').read_text())

    def test_curated_inventory(self):
        r=self.client.get('/api/source-library')
        self.assertEqual(r.status_code,200)
        data=r.json()
        self.assertEqual(len(data['sites']),12)
        self.assertEqual(len(data['notes']),25)
        self.assertEqual(data['checked_at'],'2026-11-23')
    def test_source_urls_are_official_https(self):
        sites=self.index['sites']; mapping={x['id']:x for x in sites}
        self.assertEqual(len(mapping),len(sites))
        for x in sites:
            self.assertTrue(x['url'].startswith('https://'))
            self.assertTrue(x['domain'])
        for n in self.index['notes']:
            self.assertIn(n['site_id'],mapping)
            self.assertTrue(n['url'].startswith('https://'))
            self.assertTrue(n['summary'] and n['lesson'])
            self.assertNotIn('image_url',n)
    def test_third_party_screenshots_not_silently_published(self):
        for x in self.index['sites']:
            self.assertNotIn('image_url',x)
            self.assertNotIn('screenshot',x)
        self.assertIn(self.client.post('/api/admin/websites',json={'slug':'test-company','name':'Test Company','industry':'Engineering','reference_type':'Live Website'}).status_code,(401,503))
    def test_frontend_assets_serve(self):
        for path in ('/','/websites','/sections','/assets/atlas-v03.js','/assets/atlas-v03.css'):
            self.assertEqual(self.client.get(path).status_code,200,path)

if __name__=='__main__':unittest.main()
