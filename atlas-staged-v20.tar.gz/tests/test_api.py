"""Basic API contract smoke tests using a temporary seeded SQLite database."""
import os
import tempfile
import unittest
from pathlib import Path

# Set env before app.main imports and creates its SQLite file.
TEST_DIR = tempfile.TemporaryDirectory(prefix="atlas_api_test_")
os.environ["ATLAS_DB_PATH"] = str(Path(TEST_DIR.name) / "test.sqlite3")
os.environ["ATLAS_ADMIN_TOKEN"] = "long-test-token-for-local-unit-tests-only"

from fastapi.testclient import TestClient  # noqa E402
from app.main import app  # noqa E402

client = TestClient(app)


class TestCatalog(unittest.TestCase):
    def test_stats_and_health(self):
        result = client.get("/api/health")
        self.assertEqual(result.status_code, 200)
        self.assertTrue(result.json()["ok"])
        stats = client.get("/api/stats").json()
        self.assertEqual(stats["websites"], 12)
        self.assertEqual(stats["sections"], 48)
        self.assertEqual(stats["patterns"], 12)

    def test_filter_catalog(self):
        result = client.get("/api/sections", params={"type": "Hero", "industry": "Manufacturing"})
        self.assertEqual(result.status_code, 200)
        self.assertTrue(result.json()["items"])
        self.assertTrue(all(x["type"] == "Hero" and x["industry"] == "Manufacturing" for x in result.json()["items"]))
        self.assertEqual(client.get("/api/websites/unknown-example").status_code,404)

    def test_curator_authentication_and_content(self):
        self.assertEqual(client.post("/api/admin/websites", json={"slug":"sample","name":"Sample","industry":"Engineering"}).status_code,401)
        header={"X-Admin-Token":"long-test-token-for-local-unit-tests-only"}
        payload={"slug":"new-study", "name":"New Original Study", "industry":"Engineering", "reference_type":"Original Study"}
        result=client.post("/api/admin/websites",headers=header,json=payload)
        self.assertEqual(result.status_code,201, result.text)
        self.assertEqual(client.get("/api/websites/new-study").status_code,200)
        new_section={"slug":"new-study-hero", "website_slug":"new-study", "type":"Hero", "title":"Build the next idea", "layout":"Asymmetric Split"}
        result=client.post("/api/admin/sections",headers=header,json=new_section)
        self.assertEqual(result.status_code,201,result.text)
        self.assertEqual(client.get("/api/sections/new-study-hero").status_code,200)
        result=client.delete("/api/admin/websites/new-study",headers=header)
        self.assertEqual(result.status_code,200)
        self.assertEqual(client.get("/api/websites/new-study").status_code,404)

    def test_invalid_url_and_duplicates(self):
        header={"X-Admin-Token":"long-test-token-for-local-unit-tests-only"}
        result=client.post("/api/admin/websites",headers=header,json={"slug":"invalid-url", "name":"Invalid URL", "industry":"Manufacturing", "image_url":"javascript:alert(1)"})
        self.assertEqual(result.status_code,422)
        result=client.post("/api/admin/websites",headers=header,json={"slug":"ferrum-precision", "name":"Duplicate", "industry":"Manufacturing"})
        self.assertEqual(result.status_code,409)


if __name__=="__main__": unittest.main()
