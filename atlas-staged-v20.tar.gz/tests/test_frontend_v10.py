"""V1.0 design system and real-data acceptance checks."""
import json
from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app

ROOT=Path(__file__).resolve().parents[1]
client=TestClient(app)

def test_v10_frontend_assets_and_complete_replacement():
    body=client.get('/').text
    assert 'atlas-v10.js' in body and 'atlas-v10.css' in body
    assert 'atlas-v09.js' not in body and 'atlas-v09.css' not in body
    for path in ('/assets/atlas-v10.js','/assets/atlas-v10.css'):
        response=client.get(path)
        assert response.status_code==200 and len(response.content)>15000

def test_v10_core_routes():
    for path in ['/','/websites','/sections','/websites/fictiv','/sections/fictiv-capability-hero','/patterns','/collections','/board']:
        assert client.get(path).status_code==200

def test_real_websites_and_cropped_modules():
    source=client.get('/api/source-library').json()
    assert len(source['sites'])>=10
    assert sum(bool(s['screenshot_url']) for s in source['sites'])>=10
    modules=client.get('/api/module-library').json()
    assert modules['total']==16
    for entry in modules['modules']:
        assert entry['screenshot_url'].startswith('/screenshots/modules/')
        assert client.get(entry['screenshot_url']).status_code==200
        assert client.get(entry['source_capture']).status_code==200

def test_modules_are_real_pixel_crops_not_illustrations():
    from PIL import Image
    catalog=json.loads((ROOT/'app/module_catalog.json').read_text())
    for x in catalog:
        screenshot=Image.open(ROOT/'screenshots'/'notes'/f"{x['page_id']}.webp")
        crop=Image.open(ROOT/'screenshots'/'modules'/x['image_file'])
        l,t,r,b=x['crop_px']
        assert (r-l,b-t)==crop.size
        assert 0<=l<r<=screenshot.width and 0<=t<b<=screenshot.height

def test_v10_layout_and_behavior_built_as_new_product():
    js=(ROOT/'static/assets/atlas-v10.js').read_text()
    css=(ROOT/'static/assets/atlas-v10.css').read_text()
    for fragment in ('home-wall','filter-strip','module-grid','compare-tray','site-tile','intro-search','showComparison','showPreview','exportBrief','data-save','data-board-add','data-compare'):
        assert fragment in js or fragment in css
    assert "fetch('/api/source-library')" in js and "fetch('/api/module-library')" in js
    assert all(c in css for c in ('#FFFFFF','#F5F5F7','#111111'))
    assert 'AI concept study' not in js

def test_public_content_workflow_remains_protected():
    assert client.get('/api/health').status_code==200
    assert client.get('/api/source-library').status_code==200
