"""End-to-end editorial workflow tests with an isolated SQLite database."""
import io
import unittest
from PIL import Image
from test_api import client as CLIENT  # Shared isolated database and curator test token.

HEADER = {"X-Admin-Token": "long-test-token-for-local-unit-tests-only"}


def create(slug, **override):
    data = {"slug": slug, "name": "Verified Example", "source_url": f"https://www.example.com/{slug}", "industry": "Manufacturing", "description": "A manufacturing company website reference with clear product and engineering context.", "design_note": "The reference uses structured typography and visual evidence to support the manufacturer's identity."}
    data.update(override)
    result = CLIENT.post("/api/admin/intake", headers=HEADER, json=data)
    return result


def action(id, name, data=None):
    return CLIENT.post(f"/api/admin/intake/{id}/{name}", headers=HEADER, json=data)


def review(id, decision="approve"):
    return action(id, "review", {"decision": decision, "reviewer": "Atlas Curator", "note": "Checked reference relevance, appropriate context and correct attribution."})


class TestEditorialPipeline(unittest.TestCase):
    def test_01_auth_and_source_validation(self):
        self.assertEqual(CLIENT.get("/api/admin/intake").status_code, 401)
        self.assertEqual(CLIENT.post("/api/admin/intake", json={"slug":"abc", "name":"Test", "source_url":"https://www.example.com"}).status_code, 401)
        for url in ["http://example.com", "https://localhost/x", "https://127.0.0.1/", "https://192.168.1.8/", "https://abc.local/", "javascript:alert(1)"]:
            data = {"slug": "url-check", "name":"Invalid", "source_url":url}
            self.assertEqual(CLIENT.post("/api/admin/intake", headers=HEADER, json=data).status_code, 422, url)
        self.assertEqual(CLIENT.post("/api/admin/websites", headers=HEADER, json={"slug":"bypass-live", "name":"Bypass Live", "industry":"Manufacturing", "reference_type":"Live Website"}).status_code, 409)

    def test_02_reviewed_metadata_only_publication(self):
        result = create("metadata-example")
        self.assertEqual(result.status_code, 201, result.text)
        id = result.json()["id"]
        self.assertEqual(CLIENT.get("/api/websites/metadata-example").status_code, 404)
        self.assertEqual(action(id, "submit").status_code, 200)
        self.assertEqual(review(id).status_code, 409)
        verified = action(id, "verify", {"reviewer": "Curator One", "note": "Visited source website and confirmed that it is an official manufacturing company page."})
        self.assertEqual(verified.status_code, 200, verified.text)
        self.assertEqual(review(id).status_code, 200)
        published = action(id, "publish")
        self.assertEqual(published.status_code, 200, published.text)
        public = CLIENT.get("/api/websites/metadata-example")
        self.assertEqual(public.status_code, 200)
        self.assertIsNone(public.json()["image_url"])
        self.assertEqual(public.json()["reference_type"], "Live Website")
        audit = CLIENT.get(f"/api/admin/intake/{id}", headers=HEADER).json()["audit"]
        self.assertIn("published", [e["action"] for e in audit])

    def test_03_rights_guarded_screenshot_then_removal(self):
        result = create("rights-example")
        id = result.json()["id"]
        image = Image.new("RGB", (500, 250), (220, 231, 218))
        source = io.BytesIO();image.save(source, format="PNG"); source.seek(0)
        def upload():
            source.seek(0)
            return CLIENT.post(f"/api/admin/intake/{id}/screenshot", headers=HEADER, files={"file":("website.png", source.getvalue(), "image/png")})
        self.assertEqual(upload().status_code, 409)
        edit = CLIENT.patch(f"/api/admin/intake/{id}", headers=HEADER, json={"rights_status":"granted", "rights_holder":"Example Studio", "rights_evidence":"Signed written screenshot display permission on file #2026-01", "attribution":"Design © Example Studio"})
        self.assertEqual(edit.status_code, 200, edit.text)
        self.assertEqual(upload().status_code, 200)
        record = CLIENT.get(f"/api/admin/intake/{id}", headers=HEADER).json()
        self.assertTrue(record["screenshot_path"].startswith("/media/ref-"))
        self.assertEqual(CLIENT.get(record["screenshot_path"]).headers["content-type"], "image/webp")
        self.assertEqual(action(id, "verify", {"note":"Manual check of official website identity completed on review date.","reviewer":"Curator Two"}).status_code, 200)
        self.assertEqual(action(id, "submit").status_code, 200)
        self.assertEqual(review(id).status_code, 200)
        self.assertEqual(action(id, "publish").status_code, 200)
        public = CLIENT.get("/api/websites/rights-example").json()
        self.assertEqual(public["image_url"], record["screenshot_path"])
        denied = CLIENT.patch(f"/api/admin/intake/{id}", headers=HEADER, json={"rights_status":"revoked"})
        self.assertEqual(denied.status_code, 200, denied.text)
        self.assertEqual(CLIENT.get("/api/websites/rights-example").status_code, 404)
        record = CLIENT.get(f"/api/admin/intake/{id}", headers=HEADER).json()
        self.assertEqual(record["status"], "draft")
        self.assertIsNone(record["screenshot_path"])
        self.assertEqual(CLIENT.get(public["image_url"]).status_code, 404)

    def test_04_invalid_images_cannot_enter_catalog(self):
        id = create("unsafe-image-example").json()["id"]
        CLIENT.patch(f"/api/admin/intake/{id}", headers=HEADER, json={"rights_status":"granted", "rights_holder":"Rights Owner", "rights_evidence":"Written display permission retained by curator", "attribution":"© Rights Owner"})
        invalid = CLIENT.post(f"/api/admin/intake/{id}/screenshot", headers=HEADER, files={"file": ("fake.png", b"<svg onload=alert(1)></svg>", "image/png")})
        self.assertEqual(invalid.status_code, 422)
        oversized = CLIENT.post(f"/api/admin/intake/{id}/screenshot", headers=HEADER, files={"file": ("huge.png", b"x" * (8 * 1024 * 1024 + 1), "image/png")})
        self.assertEqual(oversized.status_code, 413)
        self.assertEqual(CLIENT.get('/media/not-found.webp').status_code, 404)

    def test_05_takedown_and_rejection(self):
        id = create("takedown-example").json()["id"]
        self.assertEqual(action(id, "verify", {"note":"Confirmed original site URL and business nature with a manual browser check.","reviewer":"Editor"}).status_code, 200)
        action(id, "submit");review(id);action(id, "publish")
        removed = action(id, "takedown", {"reason":"Owner requested withdrawal of public reference and any copied materials", "reviewer":"Editor"})
        self.assertEqual(removed.status_code, 200)
        self.assertEqual(CLIENT.get("/api/websites/takedown-example").status_code, 404)
        self.assertEqual(action(id, "publish").status_code, 409)
        self.assertEqual(review(id, "reopen").status_code, 200)
        self.assertEqual(CLIENT.get("/api/websites/takedown-example").status_code, 404)

    def test_06_permission_change_invalidates_approval(self):
        id = create("rights-change").json()["id"]
        action(id, "verify", {"note":"Verified company identity, authorship and official source by inspecting website.", "reviewer":"Editor"})
        action(id, "submit");review(id)
        res = CLIENT.patch(f"/api/admin/intake/{id}", headers=HEADER, json={"rights_status":"denied"})
        self.assertEqual(res.status_code, 200)
        self.assertEqual(action(id, "publish").status_code, 409)


if __name__ == "__main__": unittest.main()
