# B2B Atlas V1.0 — Design Discovery System

A complete front-end redesign of the B2B visual research library. V1.0 replaces the prior V0.9 interface rather than stacking more CSS patches over it.

## Visual direction
- A functional design-discovery product, not an editorial magazine or a SaaS landing page.
- Warm-paper `#F7F5F1`, white canvas `#FFFFFF`, dark ink `#17222A`, and restrained slate-blue accent `#355C7D`.
- Real-source screenshots directly drive the overall color and aesthetics. No fictitious website concepts in the public gallery.
- Unified reusable cards, filters, search, detail inspection, comparison, saved references and local design board.

## Core pages
- Home — searchable real website wall, browse by sector, preview individual real section captures.
- Websites — large screenshot gallery, grounded industry filtering, search, compact/gallery views, individual case pages.
- Sections — 16 real screenshot-region studies, purpose/industry filters, two-item comparison.
- Details — source-attributed screenshot, observation, saved and board actions.
- Saved / Board — local browser persistence; Markdown board export.

## Install and run
```bash
pip install -r requirements.txt
python create_module_catalog.py
python run.py
```
Open http://localhost:8000.

## Test
```bash
PYTHONPATH=. pytest -q
node --check static/assets/atlas-v10.js
```

## Real-source and usage limits
The project has 10 displayed real websites and 16 manually selected sections based on captured pages. An asset source URL and its metadata should remain visible. This collection is for comparison/research, not third-party code redistribution. Existing photos and screenshots belong to the original website owners; rights review and takedown workflow are important before commercial launch. Some screenshot captures can become out-of-date; they must be refreshed and reviewed.

No accounts, cloud workspace sync, or paid plans are enabled. SQLite on Render's free service is nonpersistent.
